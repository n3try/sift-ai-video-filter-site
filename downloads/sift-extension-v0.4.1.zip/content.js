"use strict";(()=>{var Re="https://sift-api.leo-r-green.workers.dev",X={enabled:!0,enableYouTube:!0,enableYouTubeShorts:!0,enableTikTok:!0,showBadge:!0,showWarnings:!0,skipMode:"off",warningThreshold:65,autoSkipThreshold:85,localWatermarkDetection:!0,reduceOnBattery:!0,showSkipNotifications:!0,privacyAnalytics:!1,apiBaseUrl:Re,onboarded:!1};var He={filteredToday:0,filteredDate:new Date().toISOString().slice(0,10),filteredTotal:0,videosChecked:0,votesSubmitted:0},De=["ai","aivideo","aiart","aifilm","aianimation","generativeai","syntheticmedia","sora","soraai","veo","veo3","runway","runwayml","kling","klingai","hailuo","minimax","pika","pikalabs","lumadreammachine","lumaai","pixverse","vidu","firefly","adobefirefly","heygen","synthesia"],Ue=["Sora","Veo","Runway","Kling","Hailuo","MiniMax","Luma Dream Machine","Pika","PixVerse","Vidu","Adobe Firefly","HeyGen","Synthesia","LTX Studio","LTX Video"],b={thresholds:{likelyAi:85,possiblyAi:65,likelyHumanMax:35,minimumEvidence:22},groupWeights:{platform_label:2,disclosure_tool:2.25,hashtag_cluster:.9,watermark:3.6,creator_prior:.75,community:2.5},aiHashtags:De,generatorNames:Ue,pointsPerPremiumDay:100,watermarkTemplates:[],disabledPlatforms:[]},C={settings:"settings",publicConfig:"publicConfig",rewards:"rewards",stats:"stats",votes:"votes",disputes:"disputes",anonymousId:"anonymousId",cachePrefix:"classification:"};function x(t,e){return`${t}:${e}`}function re(t,e){return{...t,totalVotes:e.totalVotes,weightedAiVotes:e.weightedAiVotes,weightedHumanVotes:e.weightedHumanVotes,lastUpdatedAt:e.lastUpdatedAt,offline:!1}}function J(){return typeof chrome<"u"&&!!chrome.storage?.local}async function Q(){if(!J())return X;let t=await chrome.storage.local.get(C.settings);return{...X,...t[C.settings]??{}}}async function se(){if(!J())return b;let e=(await chrome.storage.local.get(C.publicConfig))[C.publicConfig];return e?{...b,...e,thresholds:{...b.thresholds,...e.thresholds},groupWeights:{...b.groupWeights,...e.groupWeights}}:b}async function le(){return J()?(await chrome.storage.local.get(C.votes))[C.votes]??{}:{}}var Oe=[/\bmade\s+with\s+ai\b/i,/\bai[ -]?generated\b/i,/\bgenerated\s+(?:using|with)\b/i,/\bcreated\s+with\b/i,/\bai\s+(?:animation|film|video)\b/i,/\bsynthetic\s+media\b/i];function P(t){return[...new Set([...t.matchAll(/#([\p{L}\p{N}_]+)/gu)].map(e=>e[1].toLowerCase()))]}function $e(t){return t.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function Ne(t,e=b){let o=new Set(["runway","pika"]);return e.generatorNames.filter(i=>{let n=new RegExp(`\\b${$e(i)}\\b`,"i").test(t);return!n||!o.has(i.toLowerCase())?n:/#(?:runway|runwayml|pika|pikalabs)\b|\b(?:ai|generator|generated|text[ -]to[ -]video|made\s+(?:with|in)|created\s+with)\b/i.test(t)})}function D(t,e,o=b){let i=new Date().toISOString(),n=[t.title,t.caption,t.description].filter(Boolean).join(` 
`),a=[],r=e.find(f=>f.kind!=="camera_provenance"),c=e.find(f=>f.kind==="camera_provenance");if(r){let f=r.kind==="platform_auto_ai"?.96:r.kind==="platform_creator_ai"?.84:r.kind==="platform_ai_effect"?.68:.91;a.push({type:"platform_ai_label",group:"platform_label",source:r.provenance,direction:"ai",strength:f,confidence:r.kind==="platform_ai_effect"?.82:.95,detectedAt:i,metadata:{label:r.text.slice(0,160),kind:r.kind}})}c&&a.push({type:"platform_provenance_label",group:"platform_label",source:c.provenance,direction:"human",strength:.82,confidence:.9,detectedAt:i,metadata:{label:c.text.slice(0,160),kind:c.kind}}),Oe.some(f=>f.test(n))&&a.push({type:"creator_disclosure",group:"disclosure_tool",source:"creator_text",direction:"ai",strength:.86,confidence:.9,detectedAt:i});let l=Ne(n,o);l.length&&a.push({type:"generator_mention",group:"disclosure_tool",source:"creator_text",direction:"ai",strength:.65,confidence:.82,detectedAt:i,metadata:{generators:l}});let u=[...new Set([...t.hashtags,...P(n)])].filter(f=>o.aiHashtags.includes(f.toLowerCase()));return u.length&&a.push({type:"ai_hashtags",group:"hashtag_cluster",source:"creator_hashtags",direction:"ai",strength:Math.min(.68,.32+u.length*.08),confidence:.72,detectedAt:i,metadata:{hashtags:u.slice(0,12),grouped:!0}}),a}function M(t,e){for(let o of e){let n=t.querySelector(o)?.textContent?.trim();if(n)return n}return""}function Be(t){let e=t.getBoundingClientRect();return e.width>0&&e.height>0&&e.bottom>0&&e.top<window.innerHeight}function ce(t){let e=window.innerHeight/2;return t.filter(Be).map(i=>({element:i,distance:Math.abs(i.getBoundingClientRect().top+i.getBoundingClientRect().height/2-e)})).sort((i,n)=>i.distance-n.distance)[0]?.element??null}var qe=/made\s+with\s+ai|creator\s+labeled\s+as\s+ai[ -]?generated|\bai[ -]?generated\b|generated\s+by\s+ai|altered\s+or\s+synthetic\s+content|captured\s+with\s+a\s+camera/i;function de(t){return t?.replace(/\s+/g," ").trim()??""}function Fe(t,e,o=`${t}_visible_label`){let i=de(e);return!i||i.length>240||!qe.test(i)?null:/captured\s+with\s+a\s+camera/i.test(i)?{kind:"camera_provenance",text:i,provenance:o}:/creator\s+labeled\s+as\s+ai[ -]?generated/i.test(i)?{kind:"platform_creator_ai",text:i,provenance:o}:t==="tiktok"&&/\bai[ -]?generated\b/i.test(i)?{kind:"platform_auto_ai",text:i,provenance:o}:{kind:"platform_ai_unspecified",text:i,provenance:o}}function ue(t){let e=de(t);return!e||e.length>160||!/\bai\b|artificial\s+intelligence|ai\s+editor|dream\s+screen|veo/i.test(e)?null:{kind:"platform_ai_effect",text:e,provenance:"tiktok_ai_effect"}}function U(t,e,o){let i=new Set;for(let a of o.selectors)t.querySelectorAll(a).forEach(r=>i.add(r));let n=new Map;for(let a of i){if(a.closest("[hidden], [aria-hidden='true']")||o.excludeClosest?.some(c=>a.closest(c)))continue;let r=[a.getAttribute("aria-label"),a.getAttribute("title"),a.textContent];for(let c of r){let l=Fe(e,c??"",o.provenance);l&&n.set(`${l.kind}:${l.text.toLowerCase()}`,l)}}return[...n.values()]}function A(){let t=[...document.querySelectorAll("[data-e2e='recommend-list-item-container']"),...document.querySelectorAll("[data-e2e='browse-video-container']"),...document.querySelectorAll("[data-e2e='browse-video']"),...document.querySelectorAll("[data-e2e='video-container']"),...document.querySelectorAll("article"),...[...document.querySelectorAll("video")].map(e=>e.closest("[data-e2e='recommend-list-item-container'], article, [data-e2e='feed-video'], [class*='DivVideoPlayerContainer'], [class*='DivVideoContainer'], main")??e.parentElement).filter(Boolean)];return ce([...new Set(t)])}function pe(t){return t.querySelector("a[href*='/video/']")}function ze(t){let e=pe(t)?.href.match(/\/video\/(\d{1,32})/)?.[1];if(e)return e;let o=t instanceof HTMLElement?t:null,i=[...o?.matches("[data-video-id], [data-item-id], [data-aweme-id]")?[o]:[],...t.querySelectorAll("[data-video-id], [data-item-id], [data-aweme-id]")];for(let a of i)for(let r of["data-video-id","data-item-id","data-aweme-id"]){let c=a.getAttribute(r)?.match(/^\d{1,32}$/)?.[0];if(c)return c}return(o?.matches("[id^='xgwrapper-']")?o:t.querySelector("[id^='xgwrapper-']"))?.id.match(/-(\d{15,32})$/)?.[1]??null}function We(t,e){if(t.length<2)return null;let o=t[0].parentElement;for(;o&&o!==e;){if(t.every(i=>o.contains(i)))return o;o=o.parentElement}return null}var O=class{platform="tiktok";isSupportedPage(){return location.hostname.endsWith("tiktok.com")&&!!this.currentId()}currentId(e=A()){let o=location.pathname.match(/\/video\/(\d+)/)?.[1];return o||ze(e??document)}async getCurrentVideo(){let e=A()??document.body,o=this.currentId(e);if(!o)return null;let i=pe(e),n=M(e,["[data-e2e='browse-video-desc']","[data-e2e='video-desc']","h1","h2"]),a=e.querySelector("a[href^='/@'], a[href*='tiktok.com/@']"),c=(a?.getAttribute("href")??"").match(/@([^/?]+)/)?.[1];return{platform:"tiktok",platformVideoId:o,canonicalUrl:i?.href?.split("?")[0]??`https://www.tiktok.com/video/${o}`,creatorPlatformId:c,creatorDisplayName:a?.textContent?.trim(),title:n,caption:n,description:n,hashtags:P(n),pageType:"tiktok_video"}}getOfficialLabels(){let e=A()??document,o=U(e,"tiktok",{provenance:"tiktok_visible_label",selectors:["[data-e2e*='aigc' i]","[data-e2e*='ai-label' i]","[class*='AIGC' i]","[class*='Label' i]","[aria-label*='AI' i]","[title*='AI' i]","span"],excludeClosest:["[data-e2e='video-desc']","[data-e2e='browse-video-desc']","h1","h2"]}),i=e.querySelector("[data-e2e*='effect' i], a[href*='/effect/']"),n=ue(i?.textContent??i?.getAttribute("aria-label")??"");return n?[...o,n]:o}observeVideoChanges(e){let o="__initial__",i=!1,n=async()=>{i=!1;let l=await this.getCurrentVideo(),p=l?JSON.stringify({id:l.platformVideoId,caption:l.caption,creator:l.creatorPlatformId,labels:this.getOfficialLabels().map(u=>`${u.kind}:${u.text}`).sort()}):"__no_video__";p!==o&&(o=p,e(l))},a=()=>{i||(i=!0,window.setTimeout(()=>void n(),220))},r=new MutationObserver(a);r.observe(document.documentElement,{subtree:!0,childList:!0,characterData:!0,attributes:!0,attributeFilter:["class","aria-label","title"]});let c=window.setInterval(a,900);return window.addEventListener("popstate",a),document.addEventListener("scroll",a,{passive:!0}),a(),()=>{r.disconnect(),window.clearInterval(c),window.removeEventListener("popstate",a),document.removeEventListener("scroll",a)}}getUiMount(){let e=A();if(!e)return null;let o=[...e.querySelectorAll("[data-e2e='share-icon'], [data-e2e='video-share'], [data-e2e='like-icon'], [data-e2e='comment-icon'], [data-e2e='favorite-icon']")],i=We(o,e),n=o[0]??e.querySelector("[class*='ActionItem']");return i??n?.closest("[class*='ActionBarContainer']")??n?.parentElement??e}getVideoElement(){return A()?.querySelector("video")??document.querySelector("video")}async skipCurrentVideo(){let e=A(),o=[...document.querySelectorAll("[data-e2e='recommend-list-item-container']"),...document.querySelectorAll("article")],i=o.indexOf(e),n=o[i+1];return n?(n.scrollIntoView({behavior:"smooth",block:"center"}),!0):(document.dispatchEvent(new KeyboardEvent("keydown",{key:"ArrowDown",code:"ArrowDown",bubbles:!0})),!0)}async undoSkip(){return document.dispatchEvent(new KeyboardEvent("keydown",{key:"ArrowUp",code:"ArrowUp",bubbles:!0})),!0}async extractSignals(e){return D(e,this.getOfficialLabels())}};function w(){return document.querySelector("ytd-reel-video-renderer[is-active]")??[...document.querySelectorAll("ytd-reel-video-renderer")].find(t=>{let e=t.getBoundingClientRect();return e.top<innerHeight*.6&&e.bottom>innerHeight*.4})}function Z(t){for(let e of t){let o=document.querySelector(e);if(o)return o.click(),!0}return!1}function Ge(t){return[...document.querySelectorAll(t)].find(e=>{let o=getComputedStyle(e);return e.isConnected&&!e.hidden&&e.getAttribute("aria-hidden")!=="true"&&o.display!=="none"&&o.visibility!=="hidden"})??null}var $=class{platform="youtube";isSupportedPage(){let e=new URL(location.href);return e.pathname==="/watch"&&!!e.searchParams.get("v")||e.pathname.startsWith("/shorts/")}async getCurrentVideo(){let e=new URL(location.href),o=e.pathname.match(/^\/shorts\/([^/?]+)/)?.[1],i=o??e.searchParams.get("v");if(!i)return null;let n=!!o,a=n?w()??document:document,r=M(a,n?["h2","[id='video-title']","[data-title-no-tooltip]"]:["h1.ytd-watch-metadata yt-formatted-string","h1.title","#title h1"]),c=M(a,n?["#description","[id='description']","yt-formatted-string"]:["#description-inline-expander","#description","ytd-text-inline-expander"]),l=a.querySelector(n?"a.yt-simple-endpoint[href^='/@'], a[href^='/channel/']":"#owner a[href^='/@'], #owner a[href^='/channel/']"),p=l?.getAttribute("href")??"";return{platform:"youtube",platformVideoId:i,canonicalUrl:n?`https://www.youtube.com/shorts/${i}`:`https://www.youtube.com/watch?v=${i}`,creatorPlatformId:p.split("/").filter(Boolean).at(-1),creatorDisplayName:l?.textContent?.trim(),title:r,caption:n?c:r,description:c,hashtags:P(`${r} ${c}`),pageType:n?"youtube_shorts":"youtube_video"}}getOfficialLabels(){let e=location.pathname.startsWith("/shorts/"),o=e?w()??document:document;return U(o,"youtube",{provenance:e?"youtube_shorts_label":"youtube_watch_label",selectors:e?["[aria-label*='AI' i]","[title*='AI' i]","[class*='label' i]","[role='status']","span","yt-formatted-string"]:["ytd-info-panel-container-renderer *","ytd-info-panel-content-renderer *","ytd-structured-description-content-renderer [aria-label]","ytd-watch-metadata [class*='label' i]","#player [aria-label*='AI' i]","#player [title*='AI' i]","[aria-label*='Made with AI' i]","[aria-label*='Captured with a camera' i]"],excludeClosest:e?["#description","[id='description']","h1","h2"]:["#comments","ytd-watch-next-secondary-results-renderer","#related","#description-inline-expander #attributed-snippet-text"]})}observeVideoChanges(e){let o="__initial__",i=!1,n=async()=>{i=!1;let l=await this.getCurrentVideo(),p=l?JSON.stringify({id:l.platformVideoId,title:l.title,description:l.description,creator:l.creatorPlatformId,labels:this.getOfficialLabels().map(u=>`${u.kind}:${u.text}`).sort()}):"__no_video__";p!==o&&(o=p,e(l))},a=()=>{i||(i=!0,window.setTimeout(()=>void n(),180))},r=new MutationObserver(a);r.observe(document.documentElement,{subtree:!0,childList:!0,characterData:!0,attributes:!0,attributeFilter:["aria-label","title","is-active"]});let c=window.setInterval(a,1e3);return document.addEventListener("yt-navigate-finish",a),window.addEventListener("popstate",a),a(),()=>{r.disconnect(),window.clearInterval(c),document.removeEventListener("yt-navigate-finish",a),window.removeEventListener("popstate",a)}}getUiMount(){if(location.pathname.startsWith("/shorts/")){let o=w();return o?.querySelector("#actions, #right, .action-container")??o}let e=["ytd-watch-metadata #actions-inner","ytd-watch-metadata #top-level-buttons-computed","ytd-watch-metadata ytd-menu-renderer","#above-the-fold #actions-inner","#above-the-fold #actions"];for(let o of e){let i=Ge(o);if(i)return i}return null}getVideoElement(){return location.pathname.startsWith("/shorts/")?w()?.querySelector("video")??null:document.querySelector("video.html5-main-video")}async skipCurrentVideo(){return location.pathname.startsWith("/shorts/")?Z(["#navigation-button-down button","button[aria-label='Next video']","button[aria-label*='Next']"])?!0:(w()?.nextElementSibling?.scrollIntoView({behavior:"smooth",block:"center"}),!!w()?.nextElementSibling):Z([".ytp-next-button","button[aria-label*='Next']"])}async undoSkip(){return location.pathname.startsWith("/shorts/")?Z(["#navigation-button-up button","button[aria-label='Previous video']","button[aria-label*='Previous']"])?!0:(w()?.previousElementSibling?.scrollIntoView({behavior:"smooth",block:"center"}),!!w()?.previousElementSibling):(history.back(),!0)}async extractSignals(e){return D(e,this.getOfficialLabels())}};function fe(t){return{likely_ai:"Likely AI",possibly_ai:"Possibly AI",uncertain:"Uncertain",likely_human:"Likely Human",insufficient_data:"Not enough information"}[t]}var Ke=`
  :host {
    all: initial;
    --sift-panel: var(--yt-spec-menu-background, #212121);
    --sift-text: var(--yt-spec-text-primary, #f1f1f1);
    --sift-muted: var(--yt-spec-text-secondary, #aaa);
    --sift-chip: var(--yt-spec-badge-chip-background, rgba(255,255,255,.1));
    --sift-chip-hover: var(--yt-spec-button-chip-background-hover, rgba(255,255,255,.16));
    --sift-line: var(--yt-spec-10-percent-layer, rgba(255,255,255,.12));
    --sift-focus: #3ea6ff;
    display: inline-flex;
    position: relative;
    z-index: 2147483000;
    margin: 0 4px;
    overflow: visible;
    font-family: Roboto, Arial, sans-serif;
  }
  :host([data-placement="floating"]) { position: fixed; top: 74px; right: 18px; margin: 0; }
  :host([data-page-type="youtube_shorts"]),
  :host([data-page-type="tiktok_video"]) {
    --sift-panel: #242424;
    --sift-text: #fff;
    --sift-muted: #b8b8b8;
    --sift-chip: rgba(255,255,255,.12);
    --sift-chip-hover: rgba(255,255,255,.2);
    --sift-line: rgba(255,255,255,.14);
    --sift-focus: #fff;
  }
  :host([data-page-type="tiktok_video"]) { font-family: TikTokFont, ProximaNova, Arial, sans-serif; }
  :host([data-placement="inline"][data-page-type="youtube_shorts"]),
  :host([data-placement="inline"][data-page-type="tiktok_video"]) { align-self: center; margin: 6px 2px; }
  * { box-sizing: border-box; }
  button { font: inherit; }
  .wrap {
    --state: #8a8790;
    position: relative;
    display: inline-flex;
    align-items: center;
    color: var(--sift-text);
  }
  .wrap.uncertain { --state: #8a8f87; }
  .wrap.possibly_ai { --state: #bd8130; }
  .wrap.likely_ai { --state: #d65d68; }
  .wrap.likely_human { --state: #4e9874; }
  .trigger {
    min-width: 40px;
    height: 36px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 0 13px 0 9px;
    border: 0;
    border-radius: 18px;
    color: var(--sift-text);
    background: var(--sift-chip);
    cursor: pointer;
  }
  .trigger:hover { background: var(--sift-chip-hover); }
  .trigger:active { opacity: .82; }
  .trigger:focus-visible, button:focus-visible { outline: 2px solid var(--sift-focus); outline-offset: 2px; }
  .trigger-icon {
    position: relative;
    width: 20px;
    height: 20px;
    display: grid;
    place-items: center;
    flex: 0 0 auto;
    border: 1px solid transparent;
    border-radius: 6px;
    color: currentColor;
  }
  .wrap.warning .trigger-icon { border-color: var(--state); }
  .sift-mark { width: 18px; height: 18px; display: block; }
  .state-indicator {
    position: absolute;
    right: -2px;
    bottom: -1px;
    width: 7px;
    height: 7px;
    border: 2px solid var(--sift-panel);
    border-radius: 50%;
    background: var(--state);
  }
  .trigger-status { color: inherit; font-size: 12px; font-weight: 500; line-height: 1; white-space: nowrap; }
  :host([data-page-type="youtube_shorts"]) .trigger,
  :host([data-page-type="tiktok_video"]) .trigger {
    width: 54px;
    min-width: 54px;
    height: auto;
    flex-direction: column;
    gap: 5px;
    padding: 0;
    border-radius: 0;
    color: #fff;
    background: transparent;
  }
  :host([data-page-type="youtube_shorts"]) .trigger:hover,
  :host([data-page-type="tiktok_video"]) .trigger:hover { background: transparent; }
  :host([data-page-type="youtube_shorts"]) .trigger-icon,
  :host([data-page-type="tiktok_video"]) .trigger-icon {
    width: 48px;
    height: 48px;
    border: 1px solid rgba(255,255,255,.08);
    border-radius: 50%;
    background: rgba(31,31,31,.76);
  }
  :host([data-page-type="youtube_shorts"]) .trigger:hover .trigger-icon,
  :host([data-page-type="tiktok_video"]) .trigger:hover .trigger-icon { background: #3a3a3a; }
  :host([data-page-type="youtube_shorts"]) .sift-mark,
  :host([data-page-type="tiktok_video"]) .sift-mark { width: 23px; height: 23px; }
  :host([data-page-type="youtube_shorts"]) .state-indicator,
  :host([data-page-type="tiktok_video"]) .state-indicator { right: 4px; bottom: 4px; border-color: #2b2b2b; }
  :host([data-page-type="youtube_shorts"]) .trigger-status,
  :host([data-page-type="tiktok_video"]) .trigger-status { font-size: 10px; font-weight: 600; line-height: 1.2; text-align: center; }
  .tooltip {
    position: absolute;
    z-index: 4;
    right: 0;
    bottom: calc(100% + 9px);
    width: 238px;
    padding: 8px 10px;
    border: 1px solid rgba(255,255,255,.12);
    border-radius: 6px;
    color: #fff;
    background: #292929;
    box-shadow: 0 4px 12px rgba(0,0,0,.26);
    font-size: 12px;
    line-height: 1.4;
    text-align: left;
    pointer-events: none;
    visibility: hidden;
    opacity: 0;
  }
  .trigger:hover + .tooltip, .trigger:focus-visible + .tooltip { visibility: visible; opacity: 1; }
  .trigger[aria-expanded="true"] + .tooltip { visibility: hidden; opacity: 0; }
  :host([data-page-type="youtube_shorts"]) .tooltip,
  :host([data-page-type="tiktok_video"]) .tooltip { right: calc(100% + 10px); bottom: 12px; }
  .panel {
    position: absolute;
    z-index: 5;
    right: 0;
    top: auto;
    bottom: calc(100% + 10px);
    width: min(336px, calc(100vw - 24px));
    max-height: min(620px, calc(100vh - 24px));
    overflow: auto;
    padding: 16px;
    border: 1px solid var(--sift-line);
    border-radius: 12px;
    color: var(--sift-text);
    background: var(--sift-panel);
    box-shadow: 0 10px 28px rgba(0,0,0,.32);
    scrollbar-color: var(--sift-muted) transparent;
  }
  :host([data-placement="floating"]) .panel { top: calc(100% + 10px); bottom: auto; }
  :host([data-placement="inline"][data-page-type="youtube_shorts"]) .panel,
  :host([data-placement="inline"][data-page-type="tiktok_video"]) .panel { right: calc(100% + 12px); top: auto; bottom: 0; }
  .panel[hidden] { display: none; }
  .panel-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; }
  .brand-lockup { min-width: 0; display: flex; align-items: center; gap: 10px; }
  .brand-mark {
    width: 30px;
    height: 30px;
    display: grid;
    place-items: center;
    flex: 0 0 auto;
    border: 1px solid var(--sift-line);
    border-radius: 8px;
    color: var(--sift-text);
    background: var(--sift-chip);
  }
  .brand-mark .sift-mark { width: 19px; height: 19px; }
  .eyebrow { color: var(--sift-muted); font-size: 10px; font-weight: 600; letter-spacing: .08em; text-transform: uppercase; }
  h3 { margin: 2px 0 0; font-size: 16px; font-weight: 600; line-height: 1.25; }
  .offline { margin-left: 5px; color: var(--sift-muted); font-size: 10px; font-weight: 500; }
  .close {
    width: 30px;
    height: 30px;
    display: grid;
    place-items: center;
    flex: 0 0 auto;
    padding: 0;
    border: 0;
    border-radius: 50%;
    color: var(--sift-muted);
    background: transparent;
    cursor: pointer;
  }
  .close:hover { color: var(--sift-text); background: var(--sift-chip); }
  .close svg { width: 16px; height: 16px; }
  .score-row {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 16px;
    margin-top: 16px;
    padding: 13px 14px;
    border: 1px solid var(--sift-line);
    border-left: 3px solid var(--state);
    border-radius: 8px;
  }
  .score-label { display: block; color: var(--sift-muted); font-size: 11px; line-height: 1.2; }
  .score-value { display: block; margin-top: 4px; color: var(--sift-text); font-size: 24px; font-weight: 650; line-height: 1; letter-spacing: -.025em; }
  .score-value.no-score { font-size: 16px; letter-spacing: 0; }
  .state-name { color: var(--state); font-size: 11px; font-weight: 600; text-align: right; }
  .score-context { display: grid; gap: 5px; justify-items: end; }
  .evidence-strength { color: var(--sift-muted); font-size: 10px; font-weight: 500; white-space: nowrap; }
  .disclaimer { margin: 9px 0 16px; color: var(--sift-muted); font-size: 11px; line-height: 1.45; }
  .section-title { margin: 0 0 8px; color: var(--sift-muted); font-size: 10px; font-weight: 600; letter-spacing: .08em; text-transform: uppercase; }
  .reasons { list-style: none; padding: 0; margin: 0 0 14px; display: grid; gap: 8px; }
  .reasons li { position: relative; padding-left: 13px; color: var(--sift-text); font-size: 12px; line-height: 1.42; }
  .reasons li::before { content: ""; position: absolute; left: 0; top: .52em; width: 5px; height: 5px; border-radius: 50%; background: var(--sift-muted); }
  .reasons li[data-impact="strong"]::before { background: var(--state); }
  .reasons li.empty { padding-left: 0; color: var(--sift-muted); }
  .reasons li.empty::before { display: none; }
  .community {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin: 0 0 15px;
    padding: 10px 0;
    border-top: 1px solid var(--sift-line);
    border-bottom: 1px solid var(--sift-line);
    font-size: 11px;
  }
  .community span:first-child { color: var(--sift-muted); }
  .community-value { display: flex; align-items: baseline; justify-content: flex-end; gap: 7px; text-align: right; }
  .community-value strong { color: var(--sift-text); font-size: 17px; font-weight: 650; line-height: 1; }
  .community-value small { color: var(--sift-muted); font-size: 10px; font-weight: 500; }
  .vote-fieldset { min-width: 0; padding: 0; margin: 0; border: 0; }
  .vote-fieldset legend { padding: 0; margin: 0 0 8px; color: var(--sift-muted); font-size: 11px; line-height: 1.35; }
  .votes { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 6px; }
  .votes button, .skip, .report {
    min-height: 34px;
    border: 1px solid var(--sift-line);
    border-radius: 8px;
    color: var(--sift-text);
    background: transparent;
    padding: 7px 8px;
    cursor: pointer;
    font-size: 11px;
    font-weight: 600;
  }
  .votes button:hover, .skip:hover, .report:hover { background: var(--sift-chip); }
  .votes button.selected { border-color: var(--state); color: var(--state); background: var(--sift-chip); }
  .votes button.pending { border-color: var(--sift-muted); color: var(--sift-muted); }
  .votes button:disabled, .skip:disabled { cursor: wait; opacity: .62; }
  .actions { display: grid; grid-template-columns: 1fr auto; gap: 7px; margin-top: 9px; }
  .skip { color: var(--sift-panel); background: var(--sift-text); border-color: var(--sift-text); }
  .skip:hover { opacity: .9; background: var(--sift-text); }
  .report { color: var(--sift-muted); border-color: transparent; }
  .feedback { min-height: 16px; margin-top: 8px; color: var(--sift-muted); font-size: 11px; line-height: 1.4; }
  .feedback[data-tone="success"] { color: #68b98e; }
  .feedback[data-tone="error"] { color: #e47b84; }
  @media (prefers-reduced-motion: no-preference) {
    .trigger, .trigger-icon, .close, .votes button, .skip, .report { transition: background-color .12s ease, border-color .12s ease, color .12s ease, opacity .12s ease; }
  }
`,me='<svg class="sift-mark" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.25v3" fill="none" stroke="var(--sift-text)" stroke-width="1.8" stroke-linecap="round"/><rect x="3" y="5" width="18" height="17" rx="5" fill="var(--sift-text)"/><circle cx="9" cy="13" r="1.55" fill="var(--sift-panel)"/><circle cx="15" cy="13" r="1.55" fill="var(--sift-panel)"/></svg>',je='<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m5 5 10 10M15 5 5 15" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>';function y(t){return t.replace(/[&<>'"]/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"})[e])}function N(t){return Number.isFinite(t.totalVotes)?Math.max(0,Math.floor(t.totalVotes)):0}function ge(t){let e=N(t);if(!e)return"No votes yet";if(e<3)return"Too few to summarize";let o=t.weightedAiVotes+t.weightedHumanVotes;if(!o)return"No clear result";let i=t.weightedAiVotes/o;return i>=.68?"Leans AI":i<=.32?"Leans not AI":"Divided"}function Ye(t){return t==="strong"||t==="medium"?t:"weak"}function he(t,e,o,i){let n=t.shadowRoot??t.attachShadow({mode:"open"}),{result:a}=e,r=fe(a.label),c=!!i.defaultOpen,l=N(a),p=i.hosted!==!1,u=e.cached,f=d=>d.offline?u?"Last known database votes":"Database votes unavailable":u?"Last synced database votes":"Database votes",R=f(a),k=d=>{let g=N(d);return p?d.offline&&!u?"Database votes are unavailable offline.":d.offline?`Last known database count: ${g}.`:u?`Last synced database count: ${g}.`:`${g} ${g===1?"database vote":"database votes"}.`:"Database votes are unavailable in local mode."},q=e.checking?"Checking":a.displayConfidence===null?"No score":`${a.displayConfidence}%`,F=e.checking?"Sift is checking this video":a.displayConfidence===null?"Sift does not have enough evidence for an AI signal score":`AI signal score: ${a.displayConfidence}%. Assessment: ${r}`,oe=d=>e.checking?"Sift is checking available signals. Open for details.":d.displayConfidence===null?`Sift does not have enough evidence for a percentage. ${k(d)} Open for details or submit your assessment.`:`${d.displayConfidence}% AI signal score, not a probability. ${k(d)} Open to review signals or submit your assessment.`,_e=oe(a),Te=e.checking?"Checking":a.displayConfidence===null?"No score":`${a.displayConfidence}%`,Ae=ge(a),ie=p&&(!a.offline||u),Ee=a.topReasons.length?a.topReasons.map(d=>`<li data-impact="${Ye(d.impact)}">${y(d.text)}</li>`).join(""):'<li class="empty">No meaningful signals are available yet.</li>';n.innerHTML=`<style>${Ke}</style>
    <div class="wrap ${a.label} ${i.warning?"warning":""}">
      <button class="trigger" type="button" aria-expanded="${String(c)}" aria-controls="sift-detail-panel" aria-haspopup="dialog" aria-describedby="sift-trigger-tooltip" aria-label="${y(F)}. Open details.">
        <span class="trigger-icon">${me}<span class="state-indicator" aria-hidden="true"></span></span>
        <span class="trigger-status">${y(q)}</span>
      </button>
      <div class="tooltip" id="sift-trigger-tooltip" role="tooltip">${y(_e)}</div>
      <section class="panel" id="sift-detail-panel" role="dialog" aria-modal="false" aria-labelledby="sift-panel-title" ${c?"":"hidden"}>
        <header class="panel-head">
          <div class="brand-lockup">
            <span class="brand-mark">${me}</span>
            <div><div class="eyebrow">Sift assessment</div><h3 id="sift-panel-title">Video assessment${a.offline?'<span class="offline">Offline</span>':""}</h3></div>
          </div>
          <button class="close" type="button" aria-label="Close Sift details">${je}</button>
        </header>
        <div class="score-row">
          <div><span class="score-label">AI signal score</span><strong class="score-value${a.displayConfidence===null||e.checking?" no-score":""}">${y(Te)}</strong></div>
          <span class="score-context"><span class="state-name">${y(r)}</span><span class="evidence-strength">Evidence ${a.evidenceStrength}/100</span></span>
        </div>
        <p class="disclaimer">Signal agreement, not a probability or proof.</p>
        <h4 class="section-title">Signals considered</h4>
        <ul class="reasons">${Ee}</ul>
        <div class="community"><span class="database-label">${y(R)}</span><span class="community-value"><strong class="database-count">${ie?l:"\u2014"}</strong><small class="database-summary">${p?ie?y(Ae):"Offline":"Local mode"}</small></span></div>
        <fieldset class="vote-fieldset">
          <legend>How would you classify this video?</legend>
          <div class="votes" role="group" aria-label="Classify this video" aria-busy="false">
            <button type="button" data-vote="ai" aria-pressed="${String(i.existingVote==="ai")}" class="${i.existingVote==="ai"?"selected":""}">AI-generated</button>
            <button type="button" data-vote="human" aria-pressed="${String(i.existingVote==="human")}" class="${i.existingVote==="human"?"selected":""}">Not AI</button>
            <button type="button" data-vote="unsure" aria-pressed="${String(i.existingVote==="unsure")}" class="${i.existingVote==="unsure"?"selected":""}">Not sure</button>
          </div>
        </fieldset>
        <div class="actions">
          <button class="skip" type="button">Hide video</button>
          <button class="report" type="button" aria-label="Report an incorrect classification">Report result</button>
        </div>
        <div class="feedback" role="status" aria-live="polite"></div>
      </section>
    </div>`;let z=n.querySelector(".trigger"),Le=n.querySelector(".tooltip"),W=n.querySelector(".panel"),Ve=n.querySelector(".close"),G=n.querySelector(".feedback"),ne=n.querySelector(".votes"),H=[...n.querySelectorAll("[data-vote]")],Pe=n.querySelector(".database-label"),Me=n.querySelector(".database-count"),Ie=n.querySelector(".database-summary");function T(d,g="neutral"){G.textContent=d,g==="neutral"?delete G.dataset.tone:G.dataset.tone=g}function K(d,g=!1){W.hidden=!d,z.setAttribute("aria-expanded",String(d)),!d&&g&&z.focus()}z.addEventListener("click",()=>K(W.hidden)),Ve.addEventListener("click",()=>K(!1,!0)),n.addEventListener("keydown",d=>{let g=d;g.key!=="Escape"||W.hidden||(g.preventDefault(),g.stopPropagation(),K(!1,!0))});let j=!1;H.forEach(d=>{d.addEventListener("click",async()=>{if(j)return;j=!0;let g=d.dataset.vote;ne.setAttribute("aria-busy","true"),H.forEach(h=>{h.disabled=!0,h.classList.toggle("pending",h===d)}),T("Submitting your assessment...");try{let h=await o.onVote(g);H.forEach(Y=>{let ae=Y===d;Y.classList.toggle("selected",ae),Y.setAttribute("aria-pressed",String(ae))}),p&&h&&(u=!1,Pe.textContent=f(h),Me.textContent=String(N(h)),Ie.textContent=ge(h),Le.textContent=oe(h)),T("Assessment saved.","success")}catch{T("Assessment was not saved. Try again.","error")}finally{j=!1,ne.setAttribute("aria-busy","false"),H.forEach(h=>{h.disabled=!1,h.classList.remove("pending")})}})});let S=n.querySelector(".skip");S.addEventListener("click",async()=>{if(S.disabled)return;S.disabled=!0;let d=S.textContent??"Hide video";S.textContent="Hiding...",T("Hiding this video...");try{await o.onSkip(),T("")}catch{T("The video could not be hidden.","error")}finally{S.disabled=!1,S.textContent=d}}),n.querySelector(".report").addEventListener("click",o.onReport)}var Xe=`
  :host { all: initial; position: fixed; z-index: 2147483647; left: 50%; bottom: 28px; transform: translateX(-50%); font-family: Roboto, Arial, sans-serif; }
  .toast { display: flex; align-items: center; gap: 12px; max-width: min(420px, calc(100vw - 24px)); color: #f7f7f8; background: #242424; border: 1px solid rgba(255,255,255,.14); border-radius: 8px; box-shadow: 0 8px 24px rgba(0,0,0,.32); padding: 10px 10px 10px 14px; font-size: 12px; line-height: 1.35; }
  button { min-height: 30px; border: 1px solid rgba(255,255,255,.18); border-radius: 7px; background: transparent; color: #f7f7f8; padding: 6px 10px; font: 600 11px Roboto, Arial, sans-serif; cursor: pointer; }
  button:hover { background: rgba(255,255,255,.1); }
  button:focus-visible { outline: 2px solid #fff; outline-offset: 2px; }
`;function ee(t,e){document.querySelector("#sift-skip-toast")?.remove();let o=document.createElement("div");o.id="sift-skip-toast";let i=o.attachShadow({mode:"open"});i.innerHTML=`<style>${Xe}</style><div class="toast" role="status" aria-live="polite"><span>${y(t)}</span><button type="button">Undo</button></div>`,document.documentElement.append(o);let n=window.setTimeout(()=>o.remove(),7e3);i.querySelector("button")?.addEventListener("click",async()=>{window.clearTimeout(n),await e(),o.remove()})}function B(t){ee(t,async()=>{}),document.querySelector("#sift-skip-toast")?.shadowRoot?.querySelector("button")?.remove()}var Je={"top-left":[0,0],"top-right":[.72,0],"bottom-left":[0,.72],"bottom-right":[.72,.72]};function be(t){let e=t.getImageData(0,0,16,16).data,o=[];for(let i=0;i<e.length;i+=4)o.push((e[i]*.299+e[i+1]*.587+e[i+2]*.114)/255);return o}function Qe(t,e){return t.length!==e.length?0:1-t.reduce((i,n,a)=>i+Math.abs(n-e[a]),0)/t.length}async function Ze(t){let e=new Image;e.crossOrigin="anonymous",e.src=t,await e.decode();let o=document.createElement("canvas");o.width=16,o.height=16;let i=o.getContext("2d",{willReadFrequently:!0});if(!i)throw new Error("Canvas unavailable");return i.drawImage(e,0,0,16,16),be(i)}async function ye(t,e){if(!e.length||t.readyState<HTMLMediaElement.HAVE_CURRENT_DATA||!t.videoWidth)return{status:e.length?"unavailable":"clear"};try{let o=document.createElement("canvas");o.width=16,o.height=16;let i=o.getContext("2d",{willReadFrequently:!0});if(!i)return{status:"unavailable"};for(let n of e){let a=await Ze(n.assetUrl);for(let r of n.expectedRegions){let[c,l]=Je[r],p=t.videoWidth*.28,u=t.videoHeight*.28;i.clearRect(0,0,16,16),i.drawImage(t,t.videoWidth*c,t.videoHeight*l,p,u,0,0,16,16);let f=Qe(be(i),a);if(f>=n.matchingThreshold)return{status:"matched",signal:{type:"visible_watermark",group:"watermark",source:"local_template_match",direction:"ai",strength:.98,confidence:f,detectedAt:new Date().toISOString(),metadata:{generator:n.generatorName,templateId:n.id,region:r,score:f}}}}}return{status:"clear"}}catch{return{status:"unavailable"}}}var et=[new $,new O],s=null,E=null,m=0,_=null,te=!1,we=new Set,ke=new Map;function tt(){return{aiProbability:.5,displayConfidence:null,label:"insufficient_data",evidenceStrength:0,totalVotes:0,weightedAiVotes:0,weightedHumanVotes:0,topReasons:[],lastUpdatedAt:new Date().toISOString(),resolutionStatus:"unresolved"}}function V(t){return chrome.runtime.sendMessage(t)}function ot(t,e){return e.enabled?t.pageType==="youtube_video"?e.enableYouTube:t.pageType==="youtube_shorts"?e.enableYouTubeShorts:e.enableTikTok:!1}async function it(t){if(!t.reduceOnBattery)return!1;try{let o=await navigator.getBattery?.();return!!(o&&!o.charging&&o.level<.35)}catch{return!1}}async function ve(t,e,o=!1){let i=await V({type:"GET_CLASSIFICATION",video:t,signals:e,forceRefresh:o});if("error"in i)throw new Error(i.error);return i}function L(){_?.remove(),_=null}async function nt(t,e){for(let o=0;o<10;o+=1){if(e!==m)return null;let i=t.getUiMount();if(i)return{element:i,placement:"inline"};await new Promise(n=>window.setTimeout(n,120))}return e!==m?null:{element:document.body??document.documentElement,placement:"floating"}}function v(t){V({type:"CONTENT_STATE",state:t}).catch(()=>{})}function at(){m+=1,L(),s=null,v(null)}async function Se(t,e,o,i){let n=x(e.platform,e.platformVideoId);if(!await t.skipCurrentVideo()){B("Sift could not safely skip this video.");return}we.add(n),await V({type:"TRACK_FILTER"}),i&&ee(`${o?"Skipped":"Hidden"}: likely AI`,async()=>{ke.set(n,Date.now()+600*1e3),await t.undoSkip()})}function rt(t){return t.label!=="insufficient_data"&&t.resolutionStatus!=="disputed"&&t.displayConfidence!==null}async function I(t,e,o,i){if(!o.showBadge||i!==m){!o.showBadge&&i===m&&L();return}let n=await nt(t,i);if(!n||i!==m)return;let a=await le();if(i!==m)return;L();let r=document.createElement("div");r.id="sift-classification-control",r.dataset.placement=n.placement,r.dataset.pageType=e.video.pageType,_=r,n.element.append(r);let c=x(e.video.platform,e.video.platformVideoId),l=o.showWarnings&&e.result.displayConfidence!==null&&e.result.displayConfidence>=o.warningThreshold;he(r,e,{async onVote(p){let u=await V({type:"SUBMIT_VOTE",video:e.video,vote:p,result:e.result});if(u.error)throw new Error(u.error);a[c]=p;let f=u.result;return u.result&&s&&x(s.video.platform,s.video.platformVideoId)===c&&(f=re(s.result,u.result),s={...s,result:f,cached:!1},v(s)),f},async onSkip(){await Se(t,e.video,!1,o.showSkipNotifications)},onReport(){V({type:"SUBMIT_DISPUTE",video:e.video,reason:"incorrect_classification"}).then(p=>{B(p.error?"Dispute could not be submitted.":"Classification reported for review.")})}},{warning:l,existingVote:a[c],defaultOpen:o.skipMode==="ask"&&l,hosted:!!o.apiBaseUrl})}async function xe(t,e,o){if(o.skipMode!=="automatic"||!rt(e.result)||(e.result.displayConfidence??0)<o.autoSkipThreshold)return;let i=x(e.video.platform,e.video.platformVideoId);we.has(i)||(ke.get(i)??0)>Date.now()||await Se(t,e.video,!0,o.showSkipNotifications)}async function Ce(t,e){let o=++m,i=x(e.platform,e.platformVideoId),n=s?x(s.video.platform,s.video.platformVideoId):null,a=n!==i;n&&a&&L(),E=t;let r=await Q();if(!ot(e,r)||o!==m){L(),s=null,v(null);return}(a||!s)&&o===m&&(s={video:e,result:tt(),signals:[],cached:!1,checking:!0},v(s),await I(t,s,r,o));try{let c=await V({type:"GET_PUBLIC_CONFIG"}).catch(()=>se());if(c.disabledPlatforms.includes(e.platform)){L(),s=null,v(null);return}let l=await t.extractSignals(e),{result:p,cached:u}=await ve(e,l);if(o!==m)return;s={video:e,result:p,signals:l,cached:u,checking:!1},v(s),await I(t,s,r,o),await xe(t,s,r);let f=r.localWatermarkDetection&&p.resolutionStatus!=="verified"&&p.evidenceStrength<70&&!await it(r),R=t.getVideoElement();if(!f||!R||o!==m)return;let k=await ye(R,c.watermarkTemplates);if(k.status!=="matched"||!k.signal||o!==m)return;let{result:q,cached:F}=await ve(e,[...l,k.signal],!0);if(o!==m)return;s={video:e,result:q,signals:[...l,k.signal],cached:F,checking:!1},v(s),await I(t,s,r,o),await xe(t,s,r)}catch{o===m&&(s&&x(s.video.platform,s.video.platformVideoId)===i&&(s={...s,checking:!1,result:{...s.result,offline:!0,lastUpdatedAt:new Date().toISOString()}},v(s),await I(t,s,r,o)),B("Classification unavailable"))}}function st(){let t=et.find(e=>location.hostname.includes(e.platform==="youtube"?"youtube":"tiktok"));t&&(v(null),t.observeVideoChanges(e=>{e?Ce(t,e):at()}))}chrome.runtime.onMessage.addListener((t,e,o)=>{t.type==="GET_ACTIVE_STATE"&&o(s)});chrome.storage.onChanged.addListener((t,e)=>{e!=="local"||!t.settings||!s||!E||Ce(E,s.video)});st();window.setInterval(()=>{if(te||!s||!E)return;let t=E.getUiMount();!t&&_?.isConnected||t&&_?.isConnected&&_.parentElement===t&&_.dataset.placement==="inline"||(te=!0,Q().then(e=>I(E,s,e,m)).finally(()=>{te=!1}))},800);})();
