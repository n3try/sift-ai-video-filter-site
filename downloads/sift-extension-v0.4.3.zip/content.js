"use strict";(()=>{var Ne="https://sift-api.leo-r-green.workers.dev",ee={enabled:!0,enableYouTube:!0,enableYouTubeShorts:!0,enableTikTok:!0,showBadge:!0,showWarnings:!0,skipMode:"off",warningThreshold:65,autoSkipThreshold:85,localWatermarkDetection:!0,reduceOnBattery:!0,showSkipNotifications:!0,privacyAnalytics:!1,apiBaseUrl:Ne,onboarded:!1};var Be={filteredToday:0,filteredDate:new Date().toISOString().slice(0,10),filteredTotal:0,videosChecked:0,votesSubmitted:0},Fe=["ai","aivideo","aiart","aifilm","aianimation","generativeai","syntheticmedia","sora","soraai","veo","veo3","runway","runwayml","kling","klingai","hailuo","minimax","pika","pikalabs","lumadreammachine","lumaai","pixverse","vidu","firefly","adobefirefly","heygen","synthesia"],qe=["Sora","Veo","Runway","Kling","Hailuo","MiniMax","Luma Dream Machine","Pika","PixVerse","Vidu","Adobe Firefly","HeyGen","Synthesia","LTX Studio","LTX Video"],x={thresholds:{likelyAi:85,possiblyAi:65,likelyHumanMax:35,minimumEvidence:22},groupWeights:{platform_label:2,disclosure_tool:2.25,hashtag_cluster:.9,watermark:3.6,creator_prior:.75,community:2.5},aiHashtags:Fe,generatorNames:qe,pointsPerPremiumDay:100,watermarkTemplates:[],disabledPlatforms:[]},L={settings:"settings",publicConfig:"publicConfig",rewards:"rewards",stats:"stats",votes:"votes",disputes:"disputes",anonymousId:"anonymousId",cachePrefix:"classification:"};function v(t,e){return`${t}:${e}`}function te(t,e){return{...t,totalVotes:e.totalVotes,weightedAiVotes:e.weightedAiVotes,weightedHumanVotes:e.weightedHumanVotes,lastUpdatedAt:e.lastUpdatedAt,offline:!1}}function oe(){return typeof chrome<"u"&&!!chrome.storage?.local}async function ie(){if(!oe())return ee;let t=await chrome.storage.local.get(L.settings);return{...ee,...t[L.settings]??{}}}async function me(){if(!oe())return x;let e=(await chrome.storage.local.get(L.publicConfig))[L.publicConfig];return e?{...x,...e,thresholds:{...x.thresholds,...e.thresholds},groupWeights:{...x.groupWeights,...e.groupWeights}}:x}async function ge(){return oe()?(await chrome.storage.local.get(L.votes))[L.votes]??{}:{}}var ze=[/\bmade\s+with\s+ai\b/i,/\bai[ -]?generated\b/i,/\bgenerated\s+(?:using|with)\b/i,/\bcreated\s+with\b/i,/\bai\s+(?:animation|film|video)\b/i,/\bsynthetic\s+media\b/i];function U(t){return[...new Set([...t.matchAll(/#([\p{L}\p{N}_]+)/gu)].map(e=>e[1].toLowerCase()))]}function We(t){return t.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function Ge(t,e=x){let o=new Set(["runway","pika"]);return e.generatorNames.filter(i=>{let n=new RegExp(`\\b${We(i)}\\b`,"i").test(t);return!n||!o.has(i.toLowerCase())?n:/#(?:runway|runwayml|pika|pikalabs)\b|\b(?:ai|generator|generated|text[ -]to[ -]video|made\s+(?:with|in)|created\s+with)\b/i.test(t)})}function B(t,e,o=x){let i=new Date().toISOString(),n=[t.title,t.caption,t.description].filter(Boolean).join(` 
`),a=[],s=e.find(m=>m.kind!=="camera_provenance"),c=e.find(m=>m.kind==="camera_provenance");if(s){let m=s.kind==="platform_auto_ai"?.96:s.kind==="platform_creator_ai"?.84:s.kind==="platform_ai_effect"?.68:.91;a.push({type:"platform_ai_label",group:"platform_label",source:s.provenance,direction:"ai",strength:m,confidence:s.kind==="platform_ai_effect"?.82:.95,detectedAt:i,metadata:{label:s.text.slice(0,160),kind:s.kind}})}c&&a.push({type:"platform_provenance_label",group:"platform_label",source:c.provenance,direction:"human",strength:.82,confidence:.9,detectedAt:i,metadata:{label:c.text.slice(0,160),kind:c.kind}}),ze.some(m=>m.test(n))&&a.push({type:"creator_disclosure",group:"disclosure_tool",source:"creator_text",direction:"ai",strength:.86,confidence:.9,detectedAt:i});let l=Ge(n,o);l.length&&a.push({type:"generator_mention",group:"disclosure_tool",source:"creator_text",direction:"ai",strength:.65,confidence:.82,detectedAt:i,metadata:{generators:l}});let p=[...new Set([...t.hashtags,...U(n)])].filter(m=>o.aiHashtags.includes(m.toLowerCase()));return p.length&&a.push({type:"ai_hashtags",group:"hashtag_cluster",source:"creator_hashtags",direction:"ai",strength:Math.min(.68,.32+p.length*.08),confidence:.72,detectedAt:i,metadata:{hashtags:p.slice(0,12),grouped:!0}}),a}function $(t,e){for(let o of e){let n=t.querySelector(o)?.textContent?.trim();if(n)return n}return""}function Ke(t){let e=t.getBoundingClientRect();return e.width>0&&e.height>0&&e.bottom>0&&e.top<window.innerHeight}function he(t){let e=window.innerHeight/2;return t.filter(Ke).map(i=>({element:i,distance:Math.abs(i.getBoundingClientRect().top+i.getBoundingClientRect().height/2-e)})).sort((i,n)=>i.distance-n.distance)[0]?.element??null}var je=/made\s+with\s+ai|creator\s+labeled\s+as\s+ai[ -]?generated|\bai[ -]?generated\b|generated\s+by\s+ai|altered\s+or\s+synthetic\s+content|captured\s+with\s+a\s+camera/i;function be(t){return t?.replace(/\s+/g," ").trim()??""}function Ye(t,e,o=`${t}_visible_label`){let i=be(e);return!i||i.length>240||!je.test(i)?null:/captured\s+with\s+a\s+camera/i.test(i)?{kind:"camera_provenance",text:i,provenance:o}:/creator\s+labeled\s+as\s+ai[ -]?generated/i.test(i)?{kind:"platform_creator_ai",text:i,provenance:o}:t==="tiktok"&&/\bai[ -]?generated\b/i.test(i)?{kind:"platform_auto_ai",text:i,provenance:o}:{kind:"platform_ai_unspecified",text:i,provenance:o}}function ye(t){let e=be(t);return!e||e.length>160||!/\bai\b|artificial\s+intelligence|ai\s+editor|dream\s+screen|veo/i.test(e)?null:{kind:"platform_ai_effect",text:e,provenance:"tiktok_ai_effect"}}function F(t,e,o){let i=new Set;for(let a of o.selectors)t.querySelectorAll(a).forEach(s=>i.add(s));let n=new Map;for(let a of i){if(a.closest("[hidden], [aria-hidden='true']")||o.excludeClosest?.some(c=>a.closest(c)))continue;let s=[a.getAttribute("aria-label"),a.getAttribute("title"),a.textContent];for(let c of s){let l=Ye(e,c??"",o.provenance);l&&n.set(`${l.kind}:${l.text.toLowerCase()}`,l)}}return[...n.values()]}function M(){let t=[...document.querySelectorAll("[data-e2e='recommend-list-item-container']"),...document.querySelectorAll("[data-e2e='browse-video-container']"),...document.querySelectorAll("[data-e2e='browse-video']"),...document.querySelectorAll("[data-e2e='video-container']"),...document.querySelectorAll("article"),...[...document.querySelectorAll("video")].map(e=>e.closest("[data-e2e='recommend-list-item-container'], article, [data-e2e='feed-video'], [class*='DivVideoPlayerContainer'], [class*='DivVideoContainer'], main")??e.parentElement).filter(Boolean)];return he([...new Set(t)])}function ve(t){return t.querySelector("a[href*='/video/']")}function Xe(t){let e=ve(t)?.href.match(/\/video\/(\d{1,32})/)?.[1];if(e)return e;let o=t instanceof HTMLElement?t:null,i=[...o?.matches("[data-video-id], [data-item-id], [data-aweme-id]")?[o]:[],...t.querySelectorAll("[data-video-id], [data-item-id], [data-aweme-id]")];for(let a of i)for(let s of["data-video-id","data-item-id","data-aweme-id"]){let c=a.getAttribute(s)?.match(/^\d{1,32}$/)?.[0];if(c)return c}return(o?.matches("[id^='xgwrapper-']")?o:t.querySelector("[id^='xgwrapper-']"))?.id.match(/-(\d{15,32})$/)?.[1]??null}function Je(t,e){if(t.length<2)return null;let o=t[0].parentElement;for(;o&&o!==e;){if(t.every(i=>o.contains(i)))return o;o=o.parentElement}return null}var q=class{platform="tiktok";isSupportedPage(){return location.hostname.endsWith("tiktok.com")&&!!this.currentId()}currentId(e=M()){let o=location.pathname.match(/\/video\/(\d+)/)?.[1];return o||Xe(e??document)}async getCurrentVideo(){let e=M()??document.body,o=this.currentId(e);if(!o)return null;let i=ve(e),n=$(e,["[data-e2e='browse-video-desc']","[data-e2e='video-desc']","h1","h2"]),a=e.querySelector("a[href^='/@'], a[href*='tiktok.com/@']"),c=(a?.getAttribute("href")??"").match(/@([^/?]+)/)?.[1];return{platform:"tiktok",platformVideoId:o,canonicalUrl:i?.href?.split("?")[0]??`https://www.tiktok.com/video/${o}`,creatorPlatformId:c,creatorDisplayName:a?.textContent?.trim(),title:n,caption:n,description:n,hashtags:U(n),pageType:"tiktok_video"}}getOfficialLabels(){let e=M()??document,o=F(e,"tiktok",{provenance:"tiktok_visible_label",selectors:["[data-e2e*='aigc' i]","[data-e2e*='ai-label' i]","[class*='AIGC' i]","[class*='Label' i]","[aria-label*='AI' i]","[title*='AI' i]","span"],excludeClosest:["[data-e2e='video-desc']","[data-e2e='browse-video-desc']","h1","h2"]}),i=e.querySelector("[data-e2e*='effect' i], a[href*='/effect/']"),n=ye(i?.textContent??i?.getAttribute("aria-label")??"");return n?[...o,n]:o}observeVideoChanges(e){let o="__initial__",i=!1,n=async()=>{i=!1;let l=await this.getCurrentVideo(),f=l?JSON.stringify({id:l.platformVideoId,caption:l.caption,creator:l.creatorPlatformId,labels:this.getOfficialLabels().map(p=>`${p.kind}:${p.text}`).sort()}):"__no_video__";f!==o&&(o=f,e(l))},a=()=>{i||(i=!0,window.setTimeout(()=>void n(),220))},s=new MutationObserver(a);s.observe(document.documentElement,{subtree:!0,childList:!0,characterData:!0,attributes:!0,attributeFilter:["class","aria-label","title"]});let c=window.setInterval(a,900);return window.addEventListener("popstate",a),document.addEventListener("scroll",a,{passive:!0}),a(),()=>{s.disconnect(),window.clearInterval(c),window.removeEventListener("popstate",a),document.removeEventListener("scroll",a)}}getUiMount(){let e=M();if(!e)return null;let o=[...e.querySelectorAll("[data-e2e='share-icon'], [data-e2e='video-share'], [data-e2e='like-icon'], [data-e2e='comment-icon'], [data-e2e='favorite-icon']")],i=Je(o,e),n=o[0]??e.querySelector("[class*='ActionItem']");return i??n?.closest("[class*='ActionBarContainer']")??n?.parentElement??e}getVideoElement(){return M()?.querySelector("video")??document.querySelector("video")}async skipCurrentVideo(){let e=M(),o=[...document.querySelectorAll("[data-e2e='recommend-list-item-container']"),...document.querySelectorAll("article")],i=o.indexOf(e),n=o[i+1];return n?(n.scrollIntoView({behavior:"smooth",block:"center"}),!0):(document.dispatchEvent(new KeyboardEvent("keydown",{key:"ArrowDown",code:"ArrowDown",bubbles:!0})),!0)}async undoSkip(){return document.dispatchEvent(new KeyboardEvent("keydown",{key:"ArrowUp",code:"ArrowUp",bubbles:!0})),!0}async extractSignals(e){return B(e,this.getOfficialLabels())}};function V(){return document.querySelector("ytd-reel-video-renderer[is-active]")??[...document.querySelectorAll("ytd-reel-video-renderer")].find(t=>{let e=t.getBoundingClientRect();return e.top<innerHeight*.6&&e.bottom>innerHeight*.4})}function ne(t){for(let e of t){let o=document.querySelector(e);if(o)return o.click(),!0}return!1}function Qe(t){return[...document.querySelectorAll(t)].find(e=>{let o=getComputedStyle(e);return e.isConnected&&!e.hidden&&e.getAttribute("aria-hidden")!=="true"&&o.display!=="none"&&o.visibility!=="hidden"})??null}var z=class{platform="youtube";isSupportedPage(){let e=new URL(location.href);return e.pathname==="/watch"&&!!e.searchParams.get("v")||e.pathname.startsWith("/shorts/")}async getCurrentVideo(){let e=new URL(location.href),o=e.pathname.match(/^\/shorts\/([^/?]+)/)?.[1],i=o??e.searchParams.get("v");if(!i)return null;let n=!!o,a=n?V()??document:document,s=$(a,n?["h2","[id='video-title']","[data-title-no-tooltip]"]:["h1.ytd-watch-metadata yt-formatted-string","h1.title","#title h1"]),c=$(a,n?["#description","[id='description']","yt-formatted-string"]:["#description-inline-expander","#description","ytd-text-inline-expander"]),l=a.querySelector(n?"a.yt-simple-endpoint[href^='/@'], a[href^='/channel/']":"#owner a[href^='/@'], #owner a[href^='/channel/']"),f=l?.getAttribute("href")??"";return{platform:"youtube",platformVideoId:i,canonicalUrl:n?`https://www.youtube.com/shorts/${i}`:`https://www.youtube.com/watch?v=${i}`,creatorPlatformId:f.split("/").filter(Boolean).at(-1),creatorDisplayName:l?.textContent?.trim(),title:s,caption:n?c:s,description:c,hashtags:U(`${s} ${c}`),pageType:n?"youtube_shorts":"youtube_video"}}getOfficialLabels(){let e=location.pathname.startsWith("/shorts/"),o=e?V()??document:document;return F(o,"youtube",{provenance:e?"youtube_shorts_label":"youtube_watch_label",selectors:e?["[aria-label*='AI' i]","[title*='AI' i]","[class*='label' i]","[role='status']","span","yt-formatted-string"]:["ytd-info-panel-container-renderer *","ytd-info-panel-content-renderer *","ytd-structured-description-content-renderer [aria-label]","ytd-watch-metadata [class*='label' i]","#player [aria-label*='AI' i]","#player [title*='AI' i]","[aria-label*='Made with AI' i]","[aria-label*='Captured with a camera' i]"],excludeClosest:e?["#description","[id='description']","h1","h2"]:["#comments","ytd-watch-next-secondary-results-renderer","#related","#description-inline-expander #attributed-snippet-text"]})}observeVideoChanges(e){let o="__initial__",i=!1,n=async()=>{i=!1;let l=await this.getCurrentVideo(),f=l?JSON.stringify({id:l.platformVideoId,title:l.title,description:l.description,creator:l.creatorPlatformId,labels:this.getOfficialLabels().map(p=>`${p.kind}:${p.text}`).sort()}):"__no_video__";f!==o&&(o=f,e(l))},a=()=>{i||(i=!0,window.setTimeout(()=>void n(),180))},s=new MutationObserver(a);s.observe(document.documentElement,{subtree:!0,childList:!0,characterData:!0,attributes:!0,attributeFilter:["aria-label","title","is-active"]});let c=window.setInterval(a,1e3);return document.addEventListener("yt-navigate-finish",a),window.addEventListener("popstate",a),a(),()=>{s.disconnect(),window.clearInterval(c),document.removeEventListener("yt-navigate-finish",a),window.removeEventListener("popstate",a)}}getUiMount(){if(location.pathname.startsWith("/shorts/")){let o=V();return o?.querySelector("#actions, #right, .action-container")??o}let e=["ytd-watch-metadata #actions-inner","ytd-watch-metadata #top-level-buttons-computed","ytd-watch-metadata ytd-menu-renderer","#above-the-fold #actions-inner","#above-the-fold #actions"];for(let o of e){let i=Qe(o);if(i)return i}return null}getVideoElement(){return location.pathname.startsWith("/shorts/")?V()?.querySelector("video")??null:document.querySelector("video.html5-main-video")}async skipCurrentVideo(){return location.pathname.startsWith("/shorts/")?ne(["#navigation-button-down button","button[aria-label='Next video']","button[aria-label*='Next']"])?!0:(V()?.nextElementSibling?.scrollIntoView({behavior:"smooth",block:"center"}),!!V()?.nextElementSibling):ne([".ytp-next-button","button[aria-label*='Next']"])}async undoSkip(){return location.pathname.startsWith("/shorts/")?ne(["#navigation-button-up button","button[aria-label='Previous video']","button[aria-label*='Previous']"])?!0:(V()?.previousElementSibling?.scrollIntoView({behavior:"smooth",block:"center"}),!!V()?.previousElementSibling):(history.back(),!0)}async extractSignals(e){return B(e,this.getOfficialLabels())}};function xe(t){return{likely_ai:"Likely AI",possibly_ai:"Possibly AI",uncertain:"Uncertain",likely_human:"Likely Human",insufficient_data:"Not enough information"}[t]}var Ze=`
  :host {
    all: initial;
    --sift-panel: var(--yt-spec-menu-background, #212121);
    --sift-text: var(--yt-spec-text-primary, #f1f1f1);
    --sift-muted: var(--yt-spec-text-secondary, #aaa);
    --sift-chip: var(--yt-spec-badge-chip-background, rgba(255,255,255,.1));
    --sift-chip-hover: var(--yt-spec-button-chip-background-hover, rgba(255,255,255,.16));
    --sift-line: var(--yt-spec-10-percent-layer, rgba(255,255,255,.12));
    --sift-focus: #3ea6ff;
    display: inline-flex;
    position: relative;
    z-index: 2147483000;
    margin: 0 4px;
    overflow: visible;
    font-family: Roboto, Arial, sans-serif;
  }
  :host([data-placement="floating"]) { position: fixed; top: 74px; right: 18px; margin: 0; }
  :host([data-page-type="youtube_shorts"]),
  :host([data-page-type="tiktok_video"]) {
    --sift-panel: #242424;
    --sift-text: #fff;
    --sift-muted: #b8b8b8;
    --sift-chip: rgba(255,255,255,.12);
    --sift-chip-hover: rgba(255,255,255,.2);
    --sift-line: rgba(255,255,255,.14);
    --sift-focus: #fff;
  }
  :host([data-page-type="tiktok_video"]) { font-family: TikTokFont, ProximaNova, Arial, sans-serif; }
  :host([data-placement="inline"][data-page-type="youtube_shorts"]),
  :host([data-placement="inline"][data-page-type="tiktok_video"]) { align-self: center; margin: 6px 2px; }
  * { box-sizing: border-box; }
  button { font: inherit; }
  .wrap {
    --state: #8a8790;
    position: relative;
    display: inline-flex;
    align-items: center;
    color: var(--sift-text);
  }
  .wrap.uncertain { --state: #8a8f87; }
  .wrap.possibly_ai { --state: #bd8130; }
  .wrap.likely_ai { --state: #d65d68; }
  .wrap.likely_human { --state: #4e9874; }
  .trigger {
    min-width: 40px;
    height: 36px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 0 13px 0 9px;
    border: 0;
    border-radius: 18px;
    color: var(--sift-text);
    background: var(--sift-chip);
    cursor: pointer;
  }
  .trigger:hover { background: var(--sift-chip-hover); }
  .trigger:active { opacity: .82; }
  .trigger:focus-visible, button:focus-visible { outline: 2px solid var(--sift-focus); outline-offset: 2px; }
  .trigger-icon {
    position: relative;
    width: 20px;
    height: 20px;
    display: grid;
    place-items: center;
    flex: 0 0 auto;
    border: 1px solid transparent;
    border-radius: 6px;
    color: currentColor;
  }
  .wrap.warning .trigger-icon { border-color: var(--state); }
  .sift-mark { width: 18px; height: 18px; display: block; }
  .state-indicator {
    position: absolute;
    right: -2px;
    bottom: -1px;
    width: 7px;
    height: 7px;
    border: 2px solid var(--sift-panel);
    border-radius: 50%;
    background: var(--state);
  }
  .trigger-status { color: inherit; font-size: 12px; font-weight: 500; line-height: 1; white-space: nowrap; }
  :host([data-page-type="youtube_shorts"]) .trigger,
  :host([data-page-type="tiktok_video"]) .trigger {
    width: 54px;
    min-width: 54px;
    height: auto;
    flex-direction: column;
    gap: 5px;
    padding: 0;
    border-radius: 0;
    color: #fff;
    background: transparent;
  }
  :host([data-page-type="youtube_shorts"]) .trigger:hover,
  :host([data-page-type="tiktok_video"]) .trigger:hover { background: transparent; }
  :host([data-page-type="youtube_shorts"]) .trigger-icon,
  :host([data-page-type="tiktok_video"]) .trigger-icon {
    width: 48px;
    height: 48px;
    border: 1px solid rgba(255,255,255,.08);
    border-radius: 50%;
    background: rgba(31,31,31,.76);
  }
  :host([data-page-type="youtube_shorts"]) .trigger:hover .trigger-icon,
  :host([data-page-type="tiktok_video"]) .trigger:hover .trigger-icon { background: #3a3a3a; }
  :host([data-page-type="youtube_shorts"]) .sift-mark,
  :host([data-page-type="tiktok_video"]) .sift-mark { width: 23px; height: 23px; }
  :host([data-page-type="youtube_shorts"]) .state-indicator,
  :host([data-page-type="tiktok_video"]) .state-indicator { right: 4px; bottom: 4px; border-color: #2b2b2b; }
  :host([data-page-type="youtube_shorts"]) .trigger-status,
  :host([data-page-type="tiktok_video"]) .trigger-status { font-size: 10px; font-weight: 600; line-height: 1.2; text-align: center; }
  .tooltip {
    position: absolute;
    z-index: 4;
    right: 0;
    bottom: calc(100% + 9px);
    width: 238px;
    padding: 8px 10px;
    border: 1px solid rgba(255,255,255,.12);
    border-radius: 6px;
    color: #fff;
    background: #292929;
    box-shadow: 0 4px 12px rgba(0,0,0,.26);
    font-size: 12px;
    line-height: 1.4;
    text-align: left;
    pointer-events: none;
    visibility: hidden;
    opacity: 0;
  }
  .trigger:hover + .tooltip, .trigger:focus-visible + .tooltip { visibility: visible; opacity: 1; }
  .trigger[aria-expanded="true"] + .tooltip { visibility: hidden; opacity: 0; }
  :host([data-page-type="youtube_shorts"]) .tooltip,
  :host([data-page-type="tiktok_video"]) .tooltip { right: calc(100% + 10px); bottom: 12px; }
  .panel {
    position: absolute;
    z-index: 5;
    right: 0;
    top: auto;
    bottom: calc(100% + 10px);
    width: min(336px, calc(100vw - 24px));
    max-height: min(620px, calc(100vh - 24px));
    overflow: auto;
    padding: 16px;
    border: 1px solid var(--sift-line);
    border-radius: 12px;
    color: var(--sift-text);
    background: var(--sift-panel);
    box-shadow: 0 10px 28px rgba(0,0,0,.32);
    scrollbar-color: var(--sift-muted) transparent;
  }
  :host([data-placement="floating"]) .panel { top: calc(100% + 10px); bottom: auto; }
  :host([data-placement="inline"][data-page-type="youtube_shorts"]) .panel,
  :host([data-placement="inline"][data-page-type="tiktok_video"]) .panel { right: calc(100% + 12px); top: auto; bottom: 0; }
  .panel[hidden] { display: none; }
  .panel-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; }
  .brand-lockup { min-width: 0; display: flex; align-items: center; gap: 10px; }
  .brand-mark {
    width: 30px;
    height: 30px;
    display: grid;
    place-items: center;
    flex: 0 0 auto;
    border: 1px solid var(--sift-line);
    border-radius: 8px;
    color: var(--sift-text);
    background: var(--sift-chip);
  }
  .brand-mark .sift-mark { width: 19px; height: 19px; }
  .eyebrow { color: var(--sift-muted); font-size: 10px; font-weight: 600; letter-spacing: .08em; text-transform: uppercase; }
  h3 { margin: 2px 0 0; font-size: 16px; font-weight: 600; line-height: 1.25; }
  .offline { margin-left: 5px; color: var(--sift-muted); font-size: 10px; font-weight: 500; }
  .close {
    width: 30px;
    height: 30px;
    display: grid;
    place-items: center;
    flex: 0 0 auto;
    padding: 0;
    border: 0;
    border-radius: 50%;
    color: var(--sift-muted);
    background: transparent;
    cursor: pointer;
  }
  .close:hover { color: var(--sift-text); background: var(--sift-chip); }
  .close svg { width: 16px; height: 16px; }
  .score-row {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 16px;
    margin-top: 16px;
    padding: 13px 14px;
    border: 1px solid var(--sift-line);
    border-left: 3px solid var(--state);
    border-radius: 8px;
  }
  .score-label { display: block; color: var(--sift-muted); font-size: 11px; line-height: 1.2; }
  .score-value { display: block; margin-top: 4px; color: var(--sift-text); font-size: 24px; font-weight: 650; line-height: 1; letter-spacing: -.025em; }
  .score-value.no-score { font-size: 16px; letter-spacing: 0; }
  .state-name { color: var(--state); font-size: 11px; font-weight: 600; text-align: right; }
  .score-context { display: grid; gap: 5px; justify-items: end; }
  .evidence-strength { color: var(--sift-muted); font-size: 10px; font-weight: 500; white-space: nowrap; }
  .disclaimer { margin: 9px 0 16px; color: var(--sift-muted); font-size: 11px; line-height: 1.45; }
  .section-title { margin: 0 0 8px; color: var(--sift-muted); font-size: 10px; font-weight: 600; letter-spacing: .08em; text-transform: uppercase; }
  .reasons { list-style: none; padding: 0; margin: 0 0 14px; display: grid; gap: 8px; }
  .reasons li { position: relative; padding-left: 13px; color: var(--sift-text); font-size: 12px; line-height: 1.42; }
  .reasons li::before { content: ""; position: absolute; left: 0; top: .52em; width: 5px; height: 5px; border-radius: 50%; background: var(--sift-muted); }
  .reasons li[data-impact="strong"]::before { background: var(--state); }
  .reasons li.empty { padding-left: 0; color: var(--sift-muted); }
  .reasons li.empty::before { display: none; }
  .community {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    margin: 0 0 15px;
    padding: 10px 0;
    border-top: 1px solid var(--sift-line);
    border-bottom: 1px solid var(--sift-line);
    font-size: 11px;
  }
  .community span:first-child { color: var(--sift-muted); }
  .community-value { display: flex; align-items: baseline; justify-content: flex-end; gap: 7px; text-align: right; }
  .community-value strong { color: var(--sift-text); font-size: 17px; font-weight: 650; line-height: 1; }
  .community-value small { color: var(--sift-muted); font-size: 10px; font-weight: 500; }
  .vote-fieldset { min-width: 0; padding: 0; margin: 0; border: 0; }
  .vote-fieldset legend { padding: 0; margin: 0 0 8px; color: var(--sift-muted); font-size: 11px; line-height: 1.35; }
  .votes { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 6px; }
  .votes button, .skip, .report {
    min-height: 34px;
    border: 1px solid var(--sift-line);
    border-radius: 8px;
    color: var(--sift-text);
    background: transparent;
    padding: 7px 8px;
    cursor: pointer;
    font-size: 11px;
    font-weight: 600;
  }
  .votes button:hover, .skip:hover, .report:hover { background: var(--sift-chip); }
  .votes button.selected { border-color: var(--state); color: var(--state); background: var(--sift-chip); }
  .votes button.pending { border-color: var(--sift-muted); color: var(--sift-muted); }
  .votes button:disabled, .skip:disabled { cursor: wait; opacity: .62; }
  .actions { display: grid; grid-template-columns: 1fr auto; gap: 7px; margin-top: 9px; }
  .skip { color: var(--sift-panel); background: var(--sift-text); border-color: var(--sift-text); }
  .skip:hover { opacity: .9; background: var(--sift-text); }
  .report { color: var(--sift-muted); border-color: transparent; }
  .feedback { min-height: 16px; margin-top: 8px; color: var(--sift-muted); font-size: 11px; line-height: 1.4; }
  .feedback[data-tone="success"] { color: #68b98e; }
  .feedback[data-tone="error"] { color: #e47b84; }
  @media (prefers-reduced-motion: no-preference) {
    .trigger, .trigger-icon, .close, .votes button, .skip, .report { transition: background-color .12s ease, border-color .12s ease, color .12s ease, opacity .12s ease; }
  }
`,we='<svg class="sift-mark" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.25v3" fill="none" stroke="var(--sift-text)" stroke-width="1.8" stroke-linecap="round"/><rect x="3" y="5" width="18" height="17" rx="5" fill="var(--sift-text)"/><circle cx="9" cy="13" r="1.55" fill="var(--sift-panel)"/><circle cx="15" cy="13" r="1.55" fill="var(--sift-panel)"/></svg>',et='<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m5 5 10 10M15 5 5 15" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>';function S(t){return t.replace(/[&<>'"]/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"})[e])}function W(t){return Number.isFinite(t.totalVotes)?Math.max(0,Math.floor(t.totalVotes)):0}function ke(t){let e=W(t);if(!e)return"No votes yet";if(e<3)return"Too few to summarize";let o=t.weightedAiVotes+t.weightedHumanVotes;if(!o)return"No clear result";let i=t.weightedAiVotes/o;return i>=.68?"Leans AI":i<=.32?"Leans not AI":"Divided"}function tt(t){return t==="strong"||t==="medium"?t:"weak"}function Se(t,e,o,i){let n=t.shadowRoot??t.attachShadow({mode:"open"}),{result:a}=e,s=xe(a.label),c=!!i.defaultOpen,l=W(a),f=i.hosted!==!1,p=e.cached,m=d=>d.offline?p?"Last known database votes":"Database votes unavailable":p?"Last synced database votes":"Database votes",k=m(a),h=d=>{let u=W(d);return f?d.offline&&!p?"Database votes are unavailable offline.":d.offline?`Last known database count: ${u}.`:p?`Last synced database count: ${u}.`:`${u} ${u===1?"database vote":"database votes"}.`:"Database votes are unavailable in local mode."},y=e.checking?"Checking":a.displayConfidence===null?"No score":`${a.displayConfidence}%`,T=e.checking?"Sift is checking this video":a.displayConfidence===null?"Sift does not have enough evidence for an AI signal score":`AI signal score: ${a.displayConfidence}%. Assessment: ${s}`,E=d=>e.checking?"Sift is checking available signals. Open for details.":d.displayConfidence===null?`Sift does not have enough evidence for a percentage. ${h(d)} Open for details or submit your assessment.`:`${d.displayConfidence}% AI signal score, not a probability. ${h(d)} Open to review signals or submit your assessment.`,I=E(a),se=e.checking?"Checking":a.displayConfidence===null?"No score":`${a.displayConfidence}%`,Me=ke(a),le=f&&(!a.offline||p),Re=a.topReasons.length?a.topReasons.map(d=>`<li data-impact="${tt(d.impact)}">${S(d.text)}</li>`).join(""):'<li class="empty">No meaningful signals are available yet.</li>';n.innerHTML=`<style>${Ze}</style>
    <div class="wrap ${a.label} ${i.warning?"warning":""}">
      <button class="trigger" type="button" aria-expanded="${String(c)}" aria-controls="sift-detail-panel" aria-haspopup="dialog" aria-describedby="sift-trigger-tooltip" aria-label="${S(T)}. Open details.">
        <span class="trigger-icon">${we}<span class="state-indicator" aria-hidden="true"></span></span>
        <span class="trigger-status">${S(y)}</span>
      </button>
      <div class="tooltip" id="sift-trigger-tooltip" role="tooltip">${S(I)}</div>
      <section class="panel" id="sift-detail-panel" role="dialog" aria-modal="false" aria-labelledby="sift-panel-title" ${c?"":"hidden"}>
        <header class="panel-head">
          <div class="brand-lockup">
            <span class="brand-mark">${we}</span>
            <div><div class="eyebrow">Sift assessment</div><h3 id="sift-panel-title">Video assessment${a.offline?'<span class="offline">Offline</span>':""}</h3></div>
          </div>
          <button class="close" type="button" aria-label="Close Sift details">${et}</button>
        </header>
        <div class="score-row">
          <div><span class="score-label">AI signal score</span><strong class="score-value${a.displayConfidence===null||e.checking?" no-score":""}">${S(se)}</strong></div>
          <span class="score-context"><span class="state-name">${S(s)}</span><span class="evidence-strength">Evidence ${a.evidenceStrength}/100</span></span>
        </div>
        <p class="disclaimer">Signal agreement, not a probability or proof.</p>
        <h4 class="section-title">Signals considered</h4>
        <ul class="reasons">${Re}</ul>
        <div class="community"><span class="database-label">${S(k)}</span><span class="community-value"><strong class="database-count">${le?l:"\u2014"}</strong><small class="database-summary">${f?le?S(Me):"Offline":"Local mode"}</small></span></div>
        <fieldset class="vote-fieldset">
          <legend>How would you classify this video?</legend>
          <div class="votes" role="group" aria-label="Classify this video" aria-busy="false">
            <button type="button" data-vote="ai" aria-pressed="${String(i.existingVote==="ai")}" class="${i.existingVote==="ai"?"selected":""}">AI-generated</button>
            <button type="button" data-vote="human" aria-pressed="${String(i.existingVote==="human")}" class="${i.existingVote==="human"?"selected":""}">Not AI</button>
            <button type="button" data-vote="unsure" aria-pressed="${String(i.existingVote==="unsure")}" class="${i.existingVote==="unsure"?"selected":""}">Not sure</button>
          </div>
        </fieldset>
        <div class="actions">
          <button class="skip" type="button">Hide video</button>
          <button class="report" type="button" aria-label="Report an incorrect classification">Report result</button>
        </div>
        <div class="feedback" role="status" aria-live="polite"></div>
      </section>
    </div>`;let j=n.querySelector(".trigger"),He=n.querySelector(".tooltip"),Y=n.querySelector(".panel"),De=n.querySelector(".close"),X=n.querySelector(".feedback"),ce=n.querySelector(".votes"),N=[...n.querySelectorAll("[data-vote]")],Ue=n.querySelector(".database-label"),$e=n.querySelector(".database-count"),Oe=n.querySelector(".database-summary");function _(d,u="neutral"){X.textContent=d,u==="neutral"?delete X.dataset.tone:X.dataset.tone=u}function de(d,u){if(N.forEach(Z=>{let fe=Z.dataset.vote===d;Z.classList.toggle("selected",fe),Z.setAttribute("aria-pressed",String(fe))}),!u.hosted){_("Saved on this device only. Database mode is off.","success");return}if(!u.result){_("Vote recorded. Refresh to update the database count.","success");return}p=!1,Ue.textContent=m(u.result);let b=W(u.result);$e.textContent=String(b),Oe.textContent=ke(u.result),He.textContent=E(u.result);let pe=`${b} database ${b===1?"vote":"votes"}`;_(u.replaced?`Vote updated. ${pe}.`:`Vote recorded. ${pe}.`,"success")}function ue(d){let u=d instanceof Error&&d.message?` ${d.message}`:"";_(`Vote was not recorded.${u}`,"error")}function J(d,u=!1){Y.hidden=!d,j.setAttribute("aria-expanded",String(d)),!d&&u&&j.focus()}j.addEventListener("click",()=>J(Y.hidden)),De.addEventListener("click",()=>J(!1,!0)),n.addEventListener("keydown",d=>{let u=d;u.key!=="Escape"||Y.hidden||(u.preventDefault(),u.stopPropagation(),J(!1,!0))});let Q=!1;N.forEach(d=>{d.addEventListener("click",async()=>{if(Q)return;Q=!0;let u=d.dataset.vote;ce.setAttribute("aria-busy","true"),N.forEach(b=>{b.disabled=!0,b.classList.toggle("pending",b===d)}),_("Submitting your assessment...");try{de(u,await o.onVote(u))}catch(b){ue(b)}finally{Q=!1,ce.setAttribute("aria-busy","false"),N.forEach(b=>{b.disabled=!1,b.classList.remove("pending")})}})});let A=n.querySelector(".skip");return A.addEventListener("click",async()=>{if(A.disabled)return;A.disabled=!0;let d=A.textContent??"Hide video";A.textContent="Hiding...",_("Hiding this video...");try{await o.onSkip(),_("")}catch{_("The video could not be hidden.","error")}finally{A.disabled=!1,A.textContent=d}}),n.querySelector(".report").addEventListener("click",o.onReport),{applyVoteSuccess:de,applyVoteFailure:ue}}var ot=`
  :host { all: initial; position: fixed; z-index: 2147483647; left: 50%; bottom: 28px; transform: translateX(-50%); font-family: Roboto, Arial, sans-serif; }
  .toast { display: flex; align-items: center; gap: 12px; max-width: min(420px, calc(100vw - 24px)); color: #f7f7f8; background: #242424; border: 1px solid rgba(255,255,255,.14); border-radius: 8px; box-shadow: 0 8px 24px rgba(0,0,0,.32); padding: 10px 10px 10px 14px; font-size: 12px; line-height: 1.35; }
  button { min-height: 30px; border: 1px solid rgba(255,255,255,.18); border-radius: 7px; background: transparent; color: #f7f7f8; padding: 6px 10px; font: 600 11px Roboto, Arial, sans-serif; cursor: pointer; }
  button:hover { background: rgba(255,255,255,.1); }
  button:focus-visible { outline: 2px solid #fff; outline-offset: 2px; }
`;function ae(t,e){document.querySelector("#sift-skip-toast")?.remove();let o=document.createElement("div");o.id="sift-skip-toast";let i=o.attachShadow({mode:"open"});i.innerHTML=`<style>${ot}</style><div class="toast" role="status" aria-live="polite"><span>${S(t)}</span><button type="button">Undo</button></div>`,document.documentElement.append(o);let n=window.setTimeout(()=>o.remove(),7e3);i.querySelector("button")?.addEventListener("click",async()=>{window.clearTimeout(n),await e(),o.remove()})}function G(t){ae(t,async()=>{}),document.querySelector("#sift-skip-toast")?.shadowRoot?.querySelector("button")?.remove()}var it={"top-left":[0,0],"top-right":[.72,0],"bottom-left":[0,.72],"bottom-right":[.72,.72]};function Ce(t){let e=t.getImageData(0,0,16,16).data,o=[];for(let i=0;i<e.length;i+=4)o.push((e[i]*.299+e[i+1]*.587+e[i+2]*.114)/255);return o}function nt(t,e){return t.length!==e.length?0:1-t.reduce((i,n,a)=>i+Math.abs(n-e[a]),0)/t.length}async function at(t){let e=new Image;e.crossOrigin="anonymous",e.src=t,await e.decode();let o=document.createElement("canvas");o.width=16,o.height=16;let i=o.getContext("2d",{willReadFrequently:!0});if(!i)throw new Error("Canvas unavailable");return i.drawImage(e,0,0,16,16),Ce(i)}async function _e(t,e){if(!e.length||t.readyState<HTMLMediaElement.HAVE_CURRENT_DATA||!t.videoWidth)return{status:e.length?"unavailable":"clear"};try{let o=document.createElement("canvas");o.width=16,o.height=16;let i=o.getContext("2d",{willReadFrequently:!0});if(!i)return{status:"unavailable"};for(let n of e){let a=await at(n.assetUrl);for(let s of n.expectedRegions){let[c,l]=it[s],f=t.videoWidth*.28,p=t.videoHeight*.28;i.clearRect(0,0,16,16),i.drawImage(t,t.videoWidth*c,t.videoHeight*l,f,p,0,0,16,16);let m=nt(Ce(i),a);if(m>=n.matchingThreshold)return{status:"matched",signal:{type:"visible_watermark",group:"watermark",source:"local_template_match",direction:"ai",strength:.98,confidence:m,detectedAt:new Date().toISOString(),metadata:{generator:n.generatorName,templateId:n.id,region:s,score:m}}}}}return{status:"clear"}}catch{return{status:"unavailable"}}}var rt=[new z,new q],r=null,R=null,g=0,w=null,K=null,re=!1,Ae=new Set,Le=new Map,P=new Map;function st(t,e){if(P.delete(t),P.set(t,e),P.size>200){let o=P.keys().next().value;o&&P.delete(o)}}function Ve(t,e){let o=P.get(t);if(!o)return e;let i=Date.parse(e.lastUpdatedAt),n=Date.parse(o.lastUpdatedAt);return Number.isFinite(i)&&Number.isFinite(n)&&i>n&&e.totalVotes>=o.totalVotes?(P.delete(t),e):te(e,o)}function lt(){return{aiProbability:.5,displayConfidence:null,label:"insufficient_data",evidenceStrength:0,totalVotes:0,weightedAiVotes:0,weightedHumanVotes:0,topReasons:[],lastUpdatedAt:new Date().toISOString(),resolutionStatus:"unresolved"}}function D(t){return chrome.runtime.sendMessage(t)}function ct(t,e){return e.enabled?t.pageType==="youtube_video"?e.enableYouTube:t.pageType==="youtube_shorts"?e.enableYouTubeShorts:e.enableTikTok:!1}async function dt(t){if(!t.reduceOnBattery)return!1;try{let o=await navigator.getBattery?.();return!!(o&&!o.charging&&o.level<.35)}catch{return!1}}async function Te(t,e,o=!1){let i=await D({type:"GET_CLASSIFICATION",video:t,signals:e,forceRefresh:o});if("error"in i)throw new Error(i.error);return i}function H(){w?.remove(),w=null,K=null}async function ut(t,e){for(let o=0;o<10;o+=1){if(e!==g)return null;let i=t.getUiMount();if(i)return{element:i,placement:"inline"};await new Promise(n=>window.setTimeout(n,120))}return e!==g?null:{element:document.body??document.documentElement,placement:"floating"}}function C(t){D({type:"CONTENT_STATE",state:t}).catch(()=>{})}function pt(){g+=1,H(),r=null,C(null)}async function Pe(t,e,o,i){let n=v(e.platform,e.platformVideoId);if(!await t.skipCurrentVideo()){G("Sift could not safely skip this video.");return}Ae.add(n),await D({type:"TRACK_FILTER"}),i&&ae(`${o?"Skipped":"Hidden"}: likely AI`,async()=>{Le.set(n,Date.now()+600*1e3),await t.undoSkip()})}function ft(t){return t.label!=="insufficient_data"&&t.resolutionStatus!=="disputed"&&t.displayConfidence!==null}async function O(t,e,o,i){if(!o.showBadge||i!==g){!o.showBadge&&i===g&&H();return}let n=await ut(t,i);if(!n||i!==g)return;let a=await ge();if(i!==g)return;let s=v(e.video.platform,e.video.platformVideoId),c=r&&v(r.video.platform,r.video.platformVideoId)===s?r:e;H();let l=document.createElement("div");l.id="sift-classification-control",l.dataset.placement=n.placement,l.dataset.pageType=c.video.pageType,w=l,n.element.append(l);let f=v(c.video.platform,c.video.platformVideoId),p=o.showWarnings&&c.result.displayConfidence!==null&&c.result.displayConfidence>=o.warningThreshold,m=Se(l,c,{async onVote(k){let h;try{if(h=await D({type:"SUBMIT_VOTE",video:c.video,vote:k,result:c.result}),h.error)throw new Error(h.error)}catch(I){throw(r?v(r.video.platform,r.video.platformVideoId):null)===f&&w!==l&&K?.applyVoteFailure(I),I}a[f]=k;let y=h.result,T=!!(r&&v(r.video.platform,r.video.platformVideoId)===f);h.result&&r&&T&&(y=te(r.result,h.result),st(f,y),r={...r,result:y,cached:!1},C(r));let E={result:y,hosted:h.hosted??!!o.apiBaseUrl,replaced:h.replaced};return T&&w!==l&&K?.applyVoteSuccess(k,E),E},async onSkip(){await Pe(t,c.video,!1,o.showSkipNotifications)},onReport(){D({type:"SUBMIT_DISPUTE",video:c.video,reason:"incorrect_classification"}).then(k=>{G(k.error?"Dispute could not be submitted.":"Classification reported for review.")})}},{warning:p,existingVote:a[f],defaultOpen:o.skipMode==="ask"&&p,hosted:!!o.apiBaseUrl});w===l&&(K=m)}async function Ee(t,e,o){if(o.skipMode!=="automatic"||!ft(e.result)||(e.result.displayConfidence??0)<o.autoSkipThreshold)return;let i=v(e.video.platform,e.video.platformVideoId);Ae.has(i)||(Le.get(i)??0)>Date.now()||await Pe(t,e.video,!0,o.showSkipNotifications)}async function Ie(t,e){let o=++g,i=v(e.platform,e.platformVideoId),n=r?v(r.video.platform,r.video.platformVideoId):null,a=n!==i;n&&a&&H(),R=t;let s=await ie();if(!ct(e,s)||o!==g){H(),r=null,C(null);return}(a||!r)&&o===g&&(r={video:e,result:lt(),signals:[],cached:!1,checking:!0},C(r),await O(t,r,s,o));try{let c=await D({type:"GET_PUBLIC_CONFIG"}).catch(()=>me());if(c.disabledPlatforms.includes(e.platform)){H(),r=null,C(null);return}let l=await t.extractSignals(e),f=await Te(e,l);if(o!==g)return;let p=Ve(i,f.result),{cached:m}=f;r={video:e,result:p,signals:l,cached:m,checking:!1},C(r),await O(t,r,s,o),await Ee(t,r,s);let k=s.localWatermarkDetection&&p.resolutionStatus!=="verified"&&p.evidenceStrength<70&&!await dt(s),h=t.getVideoElement();if(!k||!h||o!==g)return;let y=await _e(h,c.watermarkTemplates);if(y.status!=="matched"||!y.signal||o!==g)return;let T=await Te(e,[...l,y.signal],!0);if(o!==g)return;let E=Ve(i,T.result),I=T.cached;r={video:e,result:E,signals:[...l,y.signal],cached:I,checking:!1},C(r),await O(t,r,s,o),await Ee(t,r,s)}catch{o===g&&(r&&v(r.video.platform,r.video.platformVideoId)===i&&(r={...r,checking:!1,result:{...r.result,offline:!0,lastUpdatedAt:new Date().toISOString()}},C(r),await O(t,r,s,o)),G("Classification unavailable"))}}function mt(){let t=rt.find(e=>location.hostname.includes(e.platform==="youtube"?"youtube":"tiktok"));t&&(C(null),t.observeVideoChanges(e=>{e?Ie(t,e):pt()}))}chrome.runtime.onMessage.addListener((t,e,o)=>{t.type==="GET_ACTIVE_STATE"&&o(r)});chrome.storage.onChanged.addListener((t,e)=>{e!=="local"||!t.settings||!r||!R||Ie(R,r.video)});mt();window.setInterval(()=>{if(re||!r||!R)return;let t=R.getUiMount();!t&&w?.isConnected||t&&w?.isConnected&&w.parentElement===t&&w.dataset.placement==="inline"||(re=!0,ie().then(e=>O(R,r,e,g)).finally(()=>{re=!1}))},800);})();
