"use strict";(()=>{var ye="https://sift-api.leo-r-green.workers.dev",W={enabled:!0,enableYouTube:!0,enableYouTubeShorts:!0,enableTikTok:!0,showBadge:!0,showWarnings:!0,skipMode:"off",warningThreshold:65,autoSkipThreshold:85,localWatermarkDetection:!0,reduceOnBattery:!0,showSkipNotifications:!0,privacyAnalytics:!1,apiBaseUrl:ye,onboarded:!1};var ve={filteredToday:0,filteredDate:new Date().toISOString().slice(0,10),filteredTotal:0,videosChecked:0,votesSubmitted:0},xe=["ai","aivideo","aiart","aifilm","aianimation","generativeai","syntheticmedia","sora","soraai","veo","veo3","runway","runwayml","kling","klingai","hailuo","minimax","pika","pikalabs","lumadreammachine","lumaai","pixverse","vidu","firefly","adobefirefly","heygen","synthesia"],we=["Sora","Veo","Runway","Kling","Hailuo","MiniMax","Luma Dream Machine","Pika","PixVerse","Vidu","Adobe Firefly","HeyGen","Synthesia","LTX Studio","LTX Video"],b={thresholds:{likelyAi:85,possiblyAi:65,likelyHumanMax:35,minimumEvidence:22},groupWeights:{platform_label:2,disclosure_tool:2.25,hashtag_cluster:.9,watermark:3.6,creator_prior:.75,community:2.5},aiHashtags:xe,generatorNames:we,pointsPerPremiumDay:100,watermarkTemplates:[],disabledPlatforms:[]},S={settings:"settings",publicConfig:"publicConfig",rewards:"rewards",stats:"stats",votes:"votes",disputes:"disputes",anonymousId:"anonymousId",cachePrefix:"classification:"};function _(t,e){return`${t}:${e}`}function K(){return typeof chrome<"u"&&!!chrome.storage?.local}async function j(){if(!K())return W;let t=await chrome.storage.local.get(S.settings);return{...W,...t[S.settings]??{}}}async function ee(){if(!K())return b;let e=(await chrome.storage.local.get(S.publicConfig))[S.publicConfig];return e?{...b,...e,thresholds:{...b.thresholds,...e.thresholds},groupWeights:{...b.groupWeights,...e.groupWeights}}:b}async function te(){return K()?(await chrome.storage.local.get(S.votes))[S.votes]??{}:{}}var ke=[/\bmade\s+with\s+ai\b/i,/\bai[ -]?generated\b/i,/\bgenerated\s+(?:using|with)\b/i,/\bcreated\s+with\b/i,/\bai\s+(?:animation|film|video)\b/i,/\bsynthetic\s+media\b/i];function I(t){return[...new Set([...t.matchAll(/#([\p{L}\p{N}_]+)/gu)].map(e=>e[1].toLowerCase()))]}function Se(t){return t.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function _e(t,e=b){let i=new Set(["runway","pika"]);return e.generatorNames.filter(o=>{let n=new RegExp(`\\b${Se(o)}\\b`,"i").test(t);return!n||!i.has(o.toLowerCase())?n:/#(?:runway|runwayml|pika|pikalabs)\b|\b(?:ai|generator|generated|text[ -]to[ -]video|made\s+(?:with|in)|created\s+with)\b/i.test(t)})}function H(t,e,i=b){let o=new Date().toISOString(),n=[t.title,t.caption,t.description].filter(Boolean).join(` 
`),a=[],r=e.find(p=>p.kind!=="camera_provenance"),l=e.find(p=>p.kind==="camera_provenance");if(r){let p=r.kind==="platform_auto_ai"?.96:r.kind==="platform_creator_ai"?.84:r.kind==="platform_ai_effect"?.68:.91;a.push({type:"platform_ai_label",group:"platform_label",source:r.provenance,direction:"ai",strength:p,confidence:r.kind==="platform_ai_effect"?.82:.95,detectedAt:o,metadata:{label:r.text.slice(0,160),kind:r.kind}})}l&&a.push({type:"platform_provenance_label",group:"platform_label",source:l.provenance,direction:"human",strength:.82,confidence:.9,detectedAt:o,metadata:{label:l.text.slice(0,160),kind:l.kind}}),ke.some(p=>p.test(n))&&a.push({type:"creator_disclosure",group:"disclosure_tool",source:"creator_text",direction:"ai",strength:.86,confidence:.9,detectedAt:o});let s=_e(n,i);s.length&&a.push({type:"generator_mention",group:"disclosure_tool",source:"creator_text",direction:"ai",strength:.65,confidence:.82,detectedAt:o,metadata:{generators:s}});let u=[...new Set([...t.hashtags,...I(n)])].filter(p=>i.aiHashtags.includes(p.toLowerCase()));return u.length&&a.push({type:"ai_hashtags",group:"hashtag_cluster",source:"creator_hashtags",direction:"ai",strength:Math.min(.68,.32+u.length*.08),confidence:.72,detectedAt:o,metadata:{hashtags:u.slice(0,12),grouped:!0}}),a}function V(t,e){for(let i of e){let n=t.querySelector(i)?.textContent?.trim();if(n)return n}return""}function Ce(t){let e=t.getBoundingClientRect();return e.width>0&&e.height>0&&e.bottom>0&&e.top<window.innerHeight}function ie(t){let e=window.innerHeight/2;return t.filter(Ce).map(o=>({element:o,distance:Math.abs(o.getBoundingClientRect().top+o.getBoundingClientRect().height/2-e)})).sort((o,n)=>o.distance-n.distance)[0]?.element??null}var Te=/made\s+with\s+ai|creator\s+labeled\s+as\s+ai[ -]?generated|\bai[ -]?generated\b|generated\s+by\s+ai|altered\s+or\s+synthetic\s+content|captured\s+with\s+a\s+camera/i;function oe(t){return t?.replace(/\s+/g," ").trim()??""}function Ee(t,e,i=`${t}_visible_label`){let o=oe(e);return!o||o.length>240||!Te.test(o)?null:/captured\s+with\s+a\s+camera/i.test(o)?{kind:"camera_provenance",text:o,provenance:i}:/creator\s+labeled\s+as\s+ai[ -]?generated/i.test(o)?{kind:"platform_creator_ai",text:o,provenance:i}:t==="tiktok"&&/\bai[ -]?generated\b/i.test(o)?{kind:"platform_auto_ai",text:o,provenance:i}:{kind:"platform_ai_unspecified",text:o,provenance:i}}function ne(t){let e=oe(t);return!e||e.length>160||!/\bai\b|artificial\s+intelligence|ai\s+editor|dream\s+screen|veo/i.test(e)?null:{kind:"platform_ai_effect",text:e,provenance:"tiktok_ai_effect"}}function D(t,e,i){let o=new Set;for(let a of i.selectors)t.querySelectorAll(a).forEach(r=>o.add(r));let n=new Map;for(let a of o){if(a.closest("[hidden], [aria-hidden='true']")||i.excludeClosest?.some(l=>a.closest(l)))continue;let r=[a.getAttribute("aria-label"),a.getAttribute("title"),a.textContent];for(let l of r){let s=Ee(e,l??"",i.provenance);s&&n.set(`${s.kind}:${s.text.toLowerCase()}`,s)}}return[...n.values()]}function E(){let t=[...document.querySelectorAll("[data-e2e='recommend-list-item-container']"),...document.querySelectorAll("[data-e2e='browse-video-container']"),...document.querySelectorAll("[data-e2e='browse-video']"),...document.querySelectorAll("[data-e2e='video-container']"),...document.querySelectorAll("article"),...[...document.querySelectorAll("video")].map(e=>e.closest("[data-e2e='recommend-list-item-container'], article, [data-e2e='feed-video'], [class*='DivVideoPlayerContainer'], [class*='DivVideoContainer'], main")??e.parentElement).filter(Boolean)];return ie([...new Set(t)])}function ae(t){return t.querySelector("a[href*='/video/']")}function Ae(t){let e=ae(t)?.href.match(/\/video\/(\d{1,32})/)?.[1];if(e)return e;let i=t instanceof HTMLElement?t:null,o=[...i?.matches("[data-video-id], [data-item-id], [data-aweme-id]")?[i]:[],...t.querySelectorAll("[data-video-id], [data-item-id], [data-aweme-id]")];for(let a of o)for(let r of["data-video-id","data-item-id","data-aweme-id"]){let l=a.getAttribute(r)?.match(/^\d{1,32}$/)?.[0];if(l)return l}return(i?.matches("[id^='xgwrapper-']")?i:t.querySelector("[id^='xgwrapper-']"))?.id.match(/-(\d{15,32})$/)?.[1]??null}function Le(t,e){if(t.length<2)return null;let i=t[0].parentElement;for(;i&&i!==e;){if(t.every(o=>i.contains(o)))return i;i=i.parentElement}return null}var $=class{platform="tiktok";isSupportedPage(){return location.hostname.endsWith("tiktok.com")&&!!this.currentId()}currentId(e=E()){let i=location.pathname.match(/\/video\/(\d+)/)?.[1];return i||Ae(e??document)}async getCurrentVideo(){let e=E()??document.body,i=this.currentId(e);if(!i)return null;let o=ae(e),n=V(e,["[data-e2e='browse-video-desc']","[data-e2e='video-desc']","h1","h2"]),a=e.querySelector("a[href^='/@'], a[href*='tiktok.com/@']"),l=(a?.getAttribute("href")??"").match(/@([^/?]+)/)?.[1];return{platform:"tiktok",platformVideoId:i,canonicalUrl:o?.href?.split("?")[0]??`https://www.tiktok.com/video/${i}`,creatorPlatformId:l,creatorDisplayName:a?.textContent?.trim(),title:n,caption:n,description:n,hashtags:I(n),pageType:"tiktok_video"}}getOfficialLabels(){let e=E()??document,i=D(e,"tiktok",{provenance:"tiktok_visible_label",selectors:["[data-e2e*='aigc' i]","[data-e2e*='ai-label' i]","[class*='AIGC' i]","[class*='Label' i]","[aria-label*='AI' i]","[title*='AI' i]","span"],excludeClosest:["[data-e2e='video-desc']","[data-e2e='browse-video-desc']","h1","h2"]}),o=e.querySelector("[data-e2e*='effect' i], a[href*='/effect/']"),n=ne(o?.textContent??o?.getAttribute("aria-label")??"");return n?[...i,n]:i}observeVideoChanges(e){let i="__initial__",o=!1,n=async()=>{o=!1;let s=await this.getCurrentVideo(),d=s?JSON.stringify({id:s.platformVideoId,caption:s.caption,creator:s.creatorPlatformId,labels:this.getOfficialLabels().map(u=>`${u.kind}:${u.text}`).sort()}):"__no_video__";d!==i&&(i=d,e(s))},a=()=>{o||(o=!0,window.setTimeout(()=>void n(),220))},r=new MutationObserver(a);r.observe(document.documentElement,{subtree:!0,childList:!0,characterData:!0,attributes:!0,attributeFilter:["class","aria-label","title"]});let l=window.setInterval(a,900);return window.addEventListener("popstate",a),document.addEventListener("scroll",a,{passive:!0}),a(),()=>{r.disconnect(),window.clearInterval(l),window.removeEventListener("popstate",a),document.removeEventListener("scroll",a)}}getUiMount(){let e=E();if(!e)return null;let i=[...e.querySelectorAll("[data-e2e='share-icon'], [data-e2e='video-share'], [data-e2e='like-icon'], [data-e2e='comment-icon'], [data-e2e='favorite-icon']")],o=Le(i,e),n=i[0]??e.querySelector("[class*='ActionItem']");return o??n?.closest("[class*='ActionBarContainer']")??n?.parentElement??e}getVideoElement(){return E()?.querySelector("video")??document.querySelector("video")}async skipCurrentVideo(){let e=E(),i=[...document.querySelectorAll("[data-e2e='recommend-list-item-container']"),...document.querySelectorAll("article")],o=i.indexOf(e),n=i[o+1];return n?(n.scrollIntoView({behavior:"smooth",block:"center"}),!0):(document.dispatchEvent(new KeyboardEvent("keydown",{key:"ArrowDown",code:"ArrowDown",bubbles:!0})),!0)}async undoSkip(){return document.dispatchEvent(new KeyboardEvent("keydown",{key:"ArrowUp",code:"ArrowUp",bubbles:!0})),!0}async extractSignals(e){return H(e,this.getOfficialLabels())}};function y(){return document.querySelector("ytd-reel-video-renderer[is-active]")??[...document.querySelectorAll("ytd-reel-video-renderer")].find(t=>{let e=t.getBoundingClientRect();return e.top<innerHeight*.6&&e.bottom>innerHeight*.4})}function Y(t){for(let e of t){let i=document.querySelector(e);if(i)return i.click(),!0}return!1}function Pe(t){return[...document.querySelectorAll(t)].find(e=>{let i=getComputedStyle(e);return e.isConnected&&!e.hidden&&e.getAttribute("aria-hidden")!=="true"&&i.display!=="none"&&i.visibility!=="hidden"})??null}var O=class{platform="youtube";isSupportedPage(){let e=new URL(location.href);return e.pathname==="/watch"&&!!e.searchParams.get("v")||e.pathname.startsWith("/shorts/")}async getCurrentVideo(){let e=new URL(location.href),i=e.pathname.match(/^\/shorts\/([^/?]+)/)?.[1],o=i??e.searchParams.get("v");if(!o)return null;let n=!!i,a=n?y()??document:document,r=V(a,n?["h2","[id='video-title']","[data-title-no-tooltip]"]:["h1.ytd-watch-metadata yt-formatted-string","h1.title","#title h1"]),l=V(a,n?["#description","[id='description']","yt-formatted-string"]:["#description-inline-expander","#description","ytd-text-inline-expander"]),s=a.querySelector(n?"a.yt-simple-endpoint[href^='/@'], a[href^='/channel/']":"#owner a[href^='/@'], #owner a[href^='/channel/']"),d=s?.getAttribute("href")??"";return{platform:"youtube",platformVideoId:o,canonicalUrl:n?`https://www.youtube.com/shorts/${o}`:`https://www.youtube.com/watch?v=${o}`,creatorPlatformId:d.split("/").filter(Boolean).at(-1),creatorDisplayName:s?.textContent?.trim(),title:r,caption:n?l:r,description:l,hashtags:I(`${r} ${l}`),pageType:n?"youtube_shorts":"youtube_video"}}getOfficialLabels(){let e=location.pathname.startsWith("/shorts/"),i=e?y()??document:document;return D(i,"youtube",{provenance:e?"youtube_shorts_label":"youtube_watch_label",selectors:e?["[aria-label*='AI' i]","[title*='AI' i]","[class*='label' i]","[role='status']","span","yt-formatted-string"]:["ytd-info-panel-container-renderer *","ytd-info-panel-content-renderer *","ytd-structured-description-content-renderer [aria-label]","ytd-watch-metadata [class*='label' i]","#player [aria-label*='AI' i]","#player [title*='AI' i]","[aria-label*='Made with AI' i]","[aria-label*='Captured with a camera' i]"],excludeClosest:e?["#description","[id='description']","h1","h2"]:["#comments","ytd-watch-next-secondary-results-renderer","#related","#description-inline-expander #attributed-snippet-text"]})}observeVideoChanges(e){let i="__initial__",o=!1,n=async()=>{o=!1;let s=await this.getCurrentVideo(),d=s?JSON.stringify({id:s.platformVideoId,title:s.title,description:s.description,creator:s.creatorPlatformId,labels:this.getOfficialLabels().map(u=>`${u.kind}:${u.text}`).sort()}):"__no_video__";d!==i&&(i=d,e(s))},a=()=>{o||(o=!0,window.setTimeout(()=>void n(),180))},r=new MutationObserver(a);r.observe(document.documentElement,{subtree:!0,childList:!0,characterData:!0,attributes:!0,attributeFilter:["aria-label","title","is-active"]});let l=window.setInterval(a,1e3);return document.addEventListener("yt-navigate-finish",a),window.addEventListener("popstate",a),a(),()=>{r.disconnect(),window.clearInterval(l),document.removeEventListener("yt-navigate-finish",a),window.removeEventListener("popstate",a)}}getUiMount(){if(location.pathname.startsWith("/shorts/")){let i=y();return i?.querySelector("#actions, #right, .action-container")??i}let e=["ytd-watch-metadata #actions-inner","ytd-watch-metadata #top-level-buttons-computed","ytd-watch-metadata ytd-menu-renderer","#above-the-fold #actions-inner","#above-the-fold #actions"];for(let i of e){let o=Pe(i);if(o)return o}return null}getVideoElement(){return location.pathname.startsWith("/shorts/")?y()?.querySelector("video")??null:document.querySelector("video.html5-main-video")}async skipCurrentVideo(){return location.pathname.startsWith("/shorts/")?Y(["#navigation-button-down button","button[aria-label='Next video']","button[aria-label*='Next']"])?!0:(y()?.nextElementSibling?.scrollIntoView({behavior:"smooth",block:"center"}),!!y()?.nextElementSibling):Y([".ytp-next-button","button[aria-label*='Next']"])}async undoSkip(){return location.pathname.startsWith("/shorts/")?Y(["#navigation-button-up button","button[aria-label='Previous video']","button[aria-label*='Previous']"])?!0:(y()?.previousElementSibling?.scrollIntoView({behavior:"smooth",block:"center"}),!!y()?.previousElementSibling):(history.back(),!0)}async extractSignals(e){return H(e,this.getOfficialLabels())}};function re(t){return{likely_ai:"Likely AI",possibly_ai:"Possibly AI",uncertain:"Uncertain",likely_human:"Likely Human",insufficient_data:"Not enough information"}[t]}var Ie=`
  :host {
    all: initial;
    --sift-panel: var(--yt-spec-menu-background, #212121);
    --sift-text: var(--yt-spec-text-primary, #f1f1f1);
    --sift-muted: var(--yt-spec-text-secondary, #aaa);
    --sift-chip: var(--yt-spec-badge-chip-background, rgba(255,255,255,.1));
    --sift-chip-hover: var(--yt-spec-button-chip-background-hover, rgba(255,255,255,.16));
    --sift-line: var(--yt-spec-10-percent-layer, rgba(255,255,255,.12));
    --sift-focus: #3ea6ff;
    display: inline-flex;
    position: relative;
    z-index: 2147483000;
    margin: 0 4px;
    overflow: visible;
    font-family: Roboto, Arial, sans-serif;
  }
  :host([data-placement="floating"]) { position: fixed; top: 74px; right: 18px; margin: 0; }
  :host([data-page-type="youtube_shorts"]),
  :host([data-page-type="tiktok_video"]) {
    --sift-panel: #242424;
    --sift-text: #fff;
    --sift-muted: #b8b8b8;
    --sift-chip: rgba(255,255,255,.12);
    --sift-chip-hover: rgba(255,255,255,.2);
    --sift-line: rgba(255,255,255,.14);
    --sift-focus: #fff;
  }
  :host([data-page-type="tiktok_video"]) { font-family: TikTokFont, ProximaNova, Arial, sans-serif; }
  :host([data-placement="inline"][data-page-type="youtube_shorts"]),
  :host([data-placement="inline"][data-page-type="tiktok_video"]) { align-self: center; margin: 6px 2px; }
  * { box-sizing: border-box; }
  button { font: inherit; }
  .wrap {
    --state: #8a8790;
    position: relative;
    display: inline-flex;
    align-items: center;
    color: var(--sift-text);
  }
  .wrap.uncertain { --state: #8a8f87; }
  .wrap.possibly_ai { --state: #bd8130; }
  .wrap.likely_ai { --state: #d65d68; }
  .wrap.likely_human { --state: #4e9874; }
  .trigger {
    min-width: 40px;
    height: 36px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 0 13px 0 9px;
    border: 0;
    border-radius: 18px;
    color: var(--sift-text);
    background: var(--sift-chip);
    cursor: pointer;
  }
  .trigger:hover { background: var(--sift-chip-hover); }
  .trigger:active { opacity: .82; }
  .trigger:focus-visible, button:focus-visible { outline: 2px solid var(--sift-focus); outline-offset: 2px; }
  .trigger-icon {
    position: relative;
    width: 20px;
    height: 20px;
    display: grid;
    place-items: center;
    flex: 0 0 auto;
    border: 1px solid transparent;
    border-radius: 6px;
    color: currentColor;
  }
  .wrap.warning .trigger-icon { border-color: var(--state); }
  .sift-mark { width: 18px; height: 18px; display: block; }
  .state-indicator {
    position: absolute;
    right: -2px;
    bottom: -1px;
    width: 7px;
    height: 7px;
    border: 2px solid var(--sift-panel);
    border-radius: 50%;
    background: var(--state);
  }
  .trigger-status { color: inherit; font-size: 12px; font-weight: 500; line-height: 1; white-space: nowrap; }
  :host([data-page-type="youtube_shorts"]) .trigger,
  :host([data-page-type="tiktok_video"]) .trigger {
    width: 54px;
    min-width: 54px;
    height: auto;
    flex-direction: column;
    gap: 5px;
    padding: 0;
    border-radius: 0;
    color: #fff;
    background: transparent;
  }
  :host([data-page-type="youtube_shorts"]) .trigger:hover,
  :host([data-page-type="tiktok_video"]) .trigger:hover { background: transparent; }
  :host([data-page-type="youtube_shorts"]) .trigger-icon,
  :host([data-page-type="tiktok_video"]) .trigger-icon {
    width: 48px;
    height: 48px;
    border: 1px solid rgba(255,255,255,.08);
    border-radius: 50%;
    background: rgba(31,31,31,.76);
  }
  :host([data-page-type="youtube_shorts"]) .trigger:hover .trigger-icon,
  :host([data-page-type="tiktok_video"]) .trigger:hover .trigger-icon { background: #3a3a3a; }
  :host([data-page-type="youtube_shorts"]) .sift-mark,
  :host([data-page-type="tiktok_video"]) .sift-mark { width: 23px; height: 23px; }
  :host([data-page-type="youtube_shorts"]) .state-indicator,
  :host([data-page-type="tiktok_video"]) .state-indicator { right: 4px; bottom: 4px; border-color: #2b2b2b; }
  :host([data-page-type="youtube_shorts"]) .trigger-status,
  :host([data-page-type="tiktok_video"]) .trigger-status { font-size: 10px; font-weight: 600; line-height: 1.2; text-align: center; }
  .tooltip {
    position: absolute;
    z-index: 4;
    right: 0;
    bottom: calc(100% + 9px);
    width: 238px;
    padding: 8px 10px;
    border: 1px solid rgba(255,255,255,.12);
    border-radius: 6px;
    color: #fff;
    background: #292929;
    box-shadow: 0 4px 12px rgba(0,0,0,.26);
    font-size: 12px;
    line-height: 1.4;
    text-align: left;
    pointer-events: none;
    visibility: hidden;
    opacity: 0;
  }
  .trigger:hover + .tooltip, .trigger:focus-visible + .tooltip { visibility: visible; opacity: 1; }
  .trigger[aria-expanded="true"] + .tooltip { visibility: hidden; opacity: 0; }
  :host([data-page-type="youtube_shorts"]) .tooltip,
  :host([data-page-type="tiktok_video"]) .tooltip { right: calc(100% + 10px); bottom: 12px; }
  .panel {
    position: absolute;
    z-index: 5;
    right: 0;
    top: auto;
    bottom: calc(100% + 10px);
    width: min(336px, calc(100vw - 24px));
    max-height: min(620px, calc(100vh - 24px));
    overflow: auto;
    padding: 16px;
    border: 1px solid var(--sift-line);
    border-radius: 12px;
    color: var(--sift-text);
    background: var(--sift-panel);
    box-shadow: 0 10px 28px rgba(0,0,0,.32);
    scrollbar-color: var(--sift-muted) transparent;
  }
  :host([data-placement="floating"]) .panel { top: calc(100% + 10px); bottom: auto; }
  :host([data-placement="inline"][data-page-type="youtube_shorts"]) .panel,
  :host([data-placement="inline"][data-page-type="tiktok_video"]) .panel { right: calc(100% + 12px); top: auto; bottom: 0; }
  .panel[hidden] { display: none; }
  .panel-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; }
  .brand-lockup { min-width: 0; display: flex; align-items: center; gap: 10px; }
  .brand-mark {
    width: 30px;
    height: 30px;
    display: grid;
    place-items: center;
    flex: 0 0 auto;
    border: 1px solid var(--sift-line);
    border-radius: 8px;
    color: var(--sift-text);
    background: var(--sift-chip);
  }
  .brand-mark .sift-mark { width: 19px; height: 19px; }
  .eyebrow { color: var(--sift-muted); font-size: 10px; font-weight: 600; letter-spacing: .08em; text-transform: uppercase; }
  h3 { margin: 2px 0 0; font-size: 16px; font-weight: 600; line-height: 1.25; }
  .offline { margin-left: 5px; color: var(--sift-muted); font-size: 10px; font-weight: 500; }
  .close {
    width: 30px;
    height: 30px;
    display: grid;
    place-items: center;
    flex: 0 0 auto;
    padding: 0;
    border: 0;
    border-radius: 50%;
    color: var(--sift-muted);
    background: transparent;
    cursor: pointer;
  }
  .close:hover { color: var(--sift-text); background: var(--sift-chip); }
  .close svg { width: 16px; height: 16px; }
  .score-row {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 16px;
    margin-top: 16px;
    padding: 13px 14px;
    border: 1px solid var(--sift-line);
    border-left: 3px solid var(--state);
    border-radius: 8px;
  }
  .score-label { display: block; color: var(--sift-muted); font-size: 11px; line-height: 1.2; }
  .score-value { display: block; margin-top: 4px; color: var(--sift-text); font-size: 24px; font-weight: 650; line-height: 1; letter-spacing: -.025em; }
  .score-value.no-score { font-size: 16px; letter-spacing: 0; }
  .state-name { color: var(--state); font-size: 11px; font-weight: 600; text-align: right; }
  .score-context { display: grid; gap: 5px; justify-items: end; }
  .evidence-strength { color: var(--sift-muted); font-size: 10px; font-weight: 500; white-space: nowrap; }
  .disclaimer { margin: 9px 0 16px; color: var(--sift-muted); font-size: 11px; line-height: 1.45; }
  .section-title { margin: 0 0 8px; color: var(--sift-muted); font-size: 10px; font-weight: 600; letter-spacing: .08em; text-transform: uppercase; }
  .reasons { list-style: none; padding: 0; margin: 0 0 14px; display: grid; gap: 8px; }
  .reasons li { position: relative; padding-left: 13px; color: var(--sift-text); font-size: 12px; line-height: 1.42; }
  .reasons li::before { content: ""; position: absolute; left: 0; top: .52em; width: 5px; height: 5px; border-radius: 50%; background: var(--sift-muted); }
  .reasons li[data-impact="strong"]::before { background: var(--state); }
  .reasons li.empty { padding-left: 0; color: var(--sift-muted); }
  .reasons li.empty::before { display: none; }
  .community {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: 12px;
    margin: 0 0 15px;
    padding: 10px 0;
    border-top: 1px solid var(--sift-line);
    border-bottom: 1px solid var(--sift-line);
    font-size: 11px;
  }
  .community span:first-child { color: var(--sift-muted); }
  .community span:last-child { color: var(--sift-text); font-weight: 500; text-align: right; }
  .vote-fieldset { min-width: 0; padding: 0; margin: 0; border: 0; }
  .vote-fieldset legend { padding: 0; margin: 0 0 8px; color: var(--sift-muted); font-size: 11px; line-height: 1.35; }
  .votes { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 6px; }
  .votes button, .skip, .report {
    min-height: 34px;
    border: 1px solid var(--sift-line);
    border-radius: 8px;
    color: var(--sift-text);
    background: transparent;
    padding: 7px 8px;
    cursor: pointer;
    font-size: 11px;
    font-weight: 600;
  }
  .votes button:hover, .skip:hover, .report:hover { background: var(--sift-chip); }
  .votes button.selected { border-color: var(--state); color: var(--state); background: var(--sift-chip); }
  .votes button.pending { border-color: var(--sift-muted); color: var(--sift-muted); }
  .votes button:disabled, .skip:disabled { cursor: wait; opacity: .62; }
  .actions { display: grid; grid-template-columns: 1fr auto; gap: 7px; margin-top: 9px; }
  .skip { color: var(--sift-panel); background: var(--sift-text); border-color: var(--sift-text); }
  .skip:hover { opacity: .9; background: var(--sift-text); }
  .report { color: var(--sift-muted); border-color: transparent; }
  .feedback { min-height: 16px; margin-top: 8px; color: var(--sift-muted); font-size: 11px; line-height: 1.4; }
  .feedback[data-tone="success"] { color: #68b98e; }
  .feedback[data-tone="error"] { color: #e47b84; }
  @media (prefers-reduced-motion: no-preference) {
    .trigger, .trigger-icon, .close, .votes button, .skip, .report { transition: background-color .12s ease, border-color .12s ease, color .12s ease, opacity .12s ease; }
  }
`,se='<svg class="sift-mark" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.25v3" fill="none" stroke="var(--sift-text)" stroke-width="1.8" stroke-linecap="round"/><rect x="3" y="5" width="18" height="17" rx="5" fill="var(--sift-text)"/><circle cx="9" cy="13" r="1.55" fill="var(--sift-panel)"/><circle cx="15" cy="13" r="1.55" fill="var(--sift-panel)"/></svg>',Ve='<svg viewBox="0 0 20 20" aria-hidden="true"><path d="m5 5 10 10M15 5 5 15" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>';function v(t){return t.replace(/[&<>'"]/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"})[e])}function Me(t){let e=Number.isFinite(t.totalVotes)?Math.max(0,Math.floor(t.totalVotes)):0;if(!e)return null;if(e<3)return`${e} ${e===1?"vote":"votes"}; too few to summarize`;let i=t.weightedAiVotes+t.weightedHumanVotes;if(!i)return`${e} votes; no clear result`;let o=t.weightedAiVotes/i;return o>=.68?`${e} votes; leans AI`:o<=.32?`${e} votes; leans not AI`:`${e} votes; divided`}function Re(t){return t==="strong"||t==="medium"?t:"weak"}function le(t,e,i,o){let n=t.shadowRoot??t.attachShadow({mode:"open"}),{result:a}=e,r=re(a.label),l=!!o.defaultOpen,s=e.checking?"Checking":a.displayConfidence===null?"No score":`${a.displayConfidence}%`,d=e.checking?"Sift is checking this video":a.displayConfidence===null?"Sift does not have enough evidence for an AI signal score":`AI signal score: ${a.displayConfidence}%. Assessment: ${r}`,u=e.checking?"Sift is checking available signals. Open for details.":a.displayConfidence===null?"Sift does not have enough evidence for a percentage. Open for details or submit your assessment.":`${a.displayConfidence}% AI signal score, not a probability. Open to review signals or submit your assessment.`,p=e.checking?"Checking":a.displayConfidence===null?"No score":`${a.displayConfidence}%`,w=Me(a),N=a.topReasons.length?a.topReasons.map(f=>`<li data-impact="${Re(f.impact)}">${v(f.text)}</li>`).join(""):'<li class="empty">No meaningful signals are available yet.</li>';n.innerHTML=`<style>${Ie}</style>
    <div class="wrap ${a.label} ${o.warning?"warning":""}">
      <button class="trigger" type="button" aria-expanded="${String(l)}" aria-controls="sift-detail-panel" aria-haspopup="dialog" aria-describedby="sift-trigger-tooltip" aria-label="${v(d)}. Open details.">
        <span class="trigger-icon">${se}<span class="state-indicator" aria-hidden="true"></span></span>
        <span class="trigger-status">${v(s)}</span>
      </button>
      <div class="tooltip" id="sift-trigger-tooltip" role="tooltip">${v(u)}</div>
      <section class="panel" id="sift-detail-panel" role="dialog" aria-modal="false" aria-labelledby="sift-panel-title" ${l?"":"hidden"}>
        <header class="panel-head">
          <div class="brand-lockup">
            <span class="brand-mark">${se}</span>
            <div><div class="eyebrow">Sift assessment</div><h3 id="sift-panel-title">Video assessment${a.offline?'<span class="offline">Offline</span>':""}</h3></div>
          </div>
          <button class="close" type="button" aria-label="Close Sift details">${Ve}</button>
        </header>
        <div class="score-row">
          <div><span class="score-label">AI signal score</span><strong class="score-value${a.displayConfidence===null||e.checking?" no-score":""}">${v(p)}</strong></div>
          <span class="score-context"><span class="state-name">${v(r)}</span><span class="evidence-strength">Evidence ${a.evidenceStrength}/100</span></span>
        </div>
        <p class="disclaimer">Signal agreement, not a probability or proof.</p>
        <h4 class="section-title">Signals considered</h4>
        <ul class="reasons">${N}</ul>
        ${w?`<div class="community"><span>Community input</span><span>${v(w)}</span></div>`:""}
        <fieldset class="vote-fieldset">
          <legend>How would you classify this video?</legend>
          <div class="votes" role="group" aria-label="Classify this video" aria-busy="false">
            <button type="button" data-vote="ai" aria-pressed="${String(o.existingVote==="ai")}" class="${o.existingVote==="ai"?"selected":""}">AI-generated</button>
            <button type="button" data-vote="human" aria-pressed="${String(o.existingVote==="human")}" class="${o.existingVote==="human"?"selected":""}">Not AI</button>
            <button type="button" data-vote="unsure" aria-pressed="${String(o.existingVote==="unsure")}" class="${o.existingVote==="unsure"?"selected":""}">Not sure</button>
          </div>
        </fieldset>
        <div class="actions">
          <button class="skip" type="button">Hide video</button>
          <button class="report" type="button" aria-label="Report an incorrect classification">Report result</button>
        </div>
        <div class="feedback" role="status" aria-live="polite"></div>
      </section>
    </div>`;let B=n.querySelector(".trigger"),q=n.querySelector(".panel"),be=n.querySelector(".close"),F=n.querySelector(".feedback"),Q=n.querySelector(".votes"),R=[...n.querySelectorAll("[data-vote]")];function T(f,g="neutral"){F.textContent=f,g==="neutral"?delete F.dataset.tone:F.dataset.tone=g}function z(f,g=!1){q.hidden=!f,B.setAttribute("aria-expanded",String(f)),!f&&g&&B.focus()}B.addEventListener("click",()=>z(q.hidden)),be.addEventListener("click",()=>z(!1,!0)),n.addEventListener("keydown",f=>{let g=f;g.key!=="Escape"||q.hidden||(g.preventDefault(),g.stopPropagation(),z(!1,!0))});let G=!1;R.forEach(f=>{f.addEventListener("click",async()=>{if(G)return;G=!0;let g=f.dataset.vote;Q.setAttribute("aria-busy","true"),R.forEach(h=>{h.disabled=!0,h.classList.toggle("pending",h===f)}),T("Submitting your assessment...");try{await i.onVote(g),R.forEach(h=>{let Z=h===f;h.classList.toggle("selected",Z),h.setAttribute("aria-pressed",String(Z))}),T("Assessment saved.","success")}catch{T("Assessment was not saved. Try again.","error")}finally{G=!1,Q.setAttribute("aria-busy","false"),R.forEach(h=>{h.disabled=!1,h.classList.remove("pending")})}})});let k=n.querySelector(".skip");k.addEventListener("click",async()=>{if(k.disabled)return;k.disabled=!0;let f=k.textContent??"Hide video";k.textContent="Hiding...",T("Hiding this video...");try{await i.onSkip(),T("")}catch{T("The video could not be hidden.","error")}finally{k.disabled=!1,k.textContent=f}}),n.querySelector(".report").addEventListener("click",i.onReport)}var He=`
  :host { all: initial; position: fixed; z-index: 2147483647; left: 50%; bottom: 28px; transform: translateX(-50%); font-family: Roboto, Arial, sans-serif; }
  .toast { display: flex; align-items: center; gap: 12px; max-width: min(420px, calc(100vw - 24px)); color: #f7f7f8; background: #242424; border: 1px solid rgba(255,255,255,.14); border-radius: 8px; box-shadow: 0 8px 24px rgba(0,0,0,.32); padding: 10px 10px 10px 14px; font-size: 12px; line-height: 1.35; }
  button { min-height: 30px; border: 1px solid rgba(255,255,255,.18); border-radius: 7px; background: transparent; color: #f7f7f8; padding: 6px 10px; font: 600 11px Roboto, Arial, sans-serif; cursor: pointer; }
  button:hover { background: rgba(255,255,255,.1); }
  button:focus-visible { outline: 2px solid #fff; outline-offset: 2px; }
`;function X(t,e){document.querySelector("#sift-skip-toast")?.remove();let i=document.createElement("div");i.id="sift-skip-toast";let o=i.attachShadow({mode:"open"});o.innerHTML=`<style>${He}</style><div class="toast" role="status" aria-live="polite"><span>${v(t)}</span><button type="button">Undo</button></div>`,document.documentElement.append(i);let n=window.setTimeout(()=>i.remove(),7e3);o.querySelector("button")?.addEventListener("click",async()=>{window.clearTimeout(n),await e(),i.remove()})}function U(t){X(t,async()=>{}),document.querySelector("#sift-skip-toast")?.shadowRoot?.querySelector("button")?.remove()}var De={"top-left":[0,0],"top-right":[.72,0],"bottom-left":[0,.72],"bottom-right":[.72,.72]};function ce(t){let e=t.getImageData(0,0,16,16).data,i=[];for(let o=0;o<e.length;o+=4)i.push((e[o]*.299+e[o+1]*.587+e[o+2]*.114)/255);return i}function $e(t,e){return t.length!==e.length?0:1-t.reduce((o,n,a)=>o+Math.abs(n-e[a]),0)/t.length}async function Oe(t){let e=new Image;e.crossOrigin="anonymous",e.src=t,await e.decode();let i=document.createElement("canvas");i.width=16,i.height=16;let o=i.getContext("2d",{willReadFrequently:!0});if(!o)throw new Error("Canvas unavailable");return o.drawImage(e,0,0,16,16),ce(o)}async function de(t,e){if(!e.length||t.readyState<HTMLMediaElement.HAVE_CURRENT_DATA||!t.videoWidth)return{status:e.length?"unavailable":"clear"};try{let i=document.createElement("canvas");i.width=16,i.height=16;let o=i.getContext("2d",{willReadFrequently:!0});if(!o)return{status:"unavailable"};for(let n of e){let a=await Oe(n.assetUrl);for(let r of n.expectedRegions){let[l,s]=De[r],d=t.videoWidth*.28,u=t.videoHeight*.28;o.clearRect(0,0,16,16),o.drawImage(t,t.videoWidth*l,t.videoHeight*s,d,u,0,0,16,16);let p=$e(ce(o),a);if(p>=n.matchingThreshold)return{status:"matched",signal:{type:"visible_watermark",group:"watermark",source:"local_template_match",direction:"ai",strength:.98,confidence:p,detectedAt:new Date().toISOString(),metadata:{generator:n.generatorName,templateId:n.id,region:r,score:p}}}}}return{status:"clear"}}catch{return{status:"unavailable"}}}var Ue=[new O,new $],c=null,A=null,m=0,C=null,J=!1,fe=new Set,me=new Map;function Ne(){return{aiProbability:.5,displayConfidence:null,label:"insufficient_data",evidenceStrength:0,totalVotes:0,weightedAiVotes:0,weightedHumanVotes:0,topReasons:[],lastUpdatedAt:new Date().toISOString(),resolutionStatus:"unresolved"}}function P(t){return chrome.runtime.sendMessage(t)}function Be(t,e){return e.enabled?t.pageType==="youtube_video"?e.enableYouTube:t.pageType==="youtube_shorts"?e.enableYouTubeShorts:e.enableTikTok:!1}async function qe(t){if(!t.reduceOnBattery)return!1;try{let i=await navigator.getBattery?.();return!!(i&&!i.charging&&i.level<.35)}catch{return!1}}async function ue(t,e,i=!1){let o=await P({type:"GET_CLASSIFICATION",video:t,signals:e,forceRefresh:i});if("error"in o)throw new Error(o.error);return o}function L(){C?.remove(),C=null}async function Fe(t,e){for(let i=0;i<10;i+=1){if(e!==m)return null;let o=t.getUiMount();if(o)return{element:o,placement:"inline"};await new Promise(n=>window.setTimeout(n,120))}return e!==m?null:{element:document.body??document.documentElement,placement:"floating"}}function x(t){P({type:"CONTENT_STATE",state:t}).catch(()=>{})}function ze(){m+=1,L(),c=null,x(null)}async function ge(t,e,i,o){let n=_(e.platform,e.platformVideoId);if(!await t.skipCurrentVideo()){U("Sift could not safely skip this video.");return}fe.add(n),await P({type:"TRACK_FILTER"}),o&&X(`${i?"Skipped":"Hidden"}: likely AI`,async()=>{me.set(n,Date.now()+600*1e3),await t.undoSkip()})}function Ge(t){return t.label!=="insufficient_data"&&t.resolutionStatus!=="disputed"&&t.displayConfidence!==null}async function M(t,e,i,o){if(!i.showBadge||o!==m){!i.showBadge&&o===m&&L();return}let n=await Fe(t,o);if(!n||o!==m)return;let a=await te();if(o!==m)return;L();let r=document.createElement("div");r.id="sift-classification-control",r.dataset.placement=n.placement,r.dataset.pageType=e.video.pageType,C=r,n.element.append(r);let l=_(e.video.platform,e.video.platformVideoId),s=i.showWarnings&&e.result.displayConfidence!==null&&e.result.displayConfidence>=i.warningThreshold;le(r,e,{async onVote(d){let u=await P({type:"SUBMIT_VOTE",video:e.video,vote:d,result:e.result});if(u.error)throw new Error(u.error)},async onSkip(){await ge(t,e.video,!1,i.showSkipNotifications)},onReport(){P({type:"SUBMIT_DISPUTE",video:e.video,reason:"incorrect_classification"}).then(d=>{U(d.error?"Dispute could not be submitted.":"Classification reported for review.")})}},{warning:s,existingVote:a[l],defaultOpen:i.skipMode==="ask"&&s})}async function pe(t,e,i){if(i.skipMode!=="automatic"||!Ge(e.result)||(e.result.displayConfidence??0)<i.autoSkipThreshold)return;let o=_(e.video.platform,e.video.platformVideoId);fe.has(o)||(me.get(o)??0)>Date.now()||await ge(t,e.video,!0,i.showSkipNotifications)}async function he(t,e){let i=++m,o=_(e.platform,e.platformVideoId),n=c?_(c.video.platform,c.video.platformVideoId):null,a=n!==o;n&&a&&L(),A=t;let r=await j();if(!Be(e,r)||i!==m){L(),c=null,x(null);return}(a||!c)&&i===m&&(c={video:e,result:Ne(),signals:[],cached:!1,checking:!0},x(c),await M(t,c,r,i));try{let l=await P({type:"GET_PUBLIC_CONFIG"}).catch(()=>ee());if(l.disabledPlatforms.includes(e.platform)){L(),c=null,x(null);return}let s=await t.extractSignals(e),d=await ue(e,s);if(i!==m)return;c={video:e,result:d,signals:s,cached:!1,checking:!1},x(c),await M(t,c,r,i),await pe(t,c,r);let u=r.localWatermarkDetection&&d.resolutionStatus!=="verified"&&d.evidenceStrength<70&&!await qe(r),p=t.getVideoElement();if(!u||!p||i!==m)return;let w=await de(p,l.watermarkTemplates);if(w.status!=="matched"||!w.signal||i!==m)return;let N=await ue(e,[...s,w.signal],!0);if(i!==m)return;c={video:e,result:N,signals:[...s,w.signal],cached:!1,checking:!1},x(c),await M(t,c,r,i),await pe(t,c,r)}catch{i===m&&(c&&_(c.video.platform,c.video.platformVideoId)===o&&(c={...c,checking:!1,result:{...c.result,offline:!0,lastUpdatedAt:new Date().toISOString()}},x(c),await M(t,c,r,i)),U("Classification unavailable"))}}function We(){let t=Ue.find(e=>location.hostname.includes(e.platform==="youtube"?"youtube":"tiktok"));t&&(x(null),t.observeVideoChanges(e=>{e?he(t,e):ze()}))}chrome.runtime.onMessage.addListener((t,e,i)=>{t.type==="GET_ACTIVE_STATE"&&i(c)});chrome.storage.onChanged.addListener((t,e)=>{e!=="local"||!t.settings||!c||!A||he(A,c.video)});We();window.setInterval(()=>{if(J||!c||!A)return;let t=A.getUiMount();!t&&C?.isConnected||t&&C?.isConnected&&C.parentElement===t&&C.dataset.placement==="inline"||(J=!0,j().then(e=>M(A,c,e,m)).finally(()=>{J=!1}))},800);})();
